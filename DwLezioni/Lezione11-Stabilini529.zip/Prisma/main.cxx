#include "EsperimentoPrisma.h"

#include <cmath>
#include <vector>
#include <iostream>
#include <cstdlib>
#include <fstream>

#define _USE_MATH_DEFINES

#include "TApplication.h"
#include "TCanvas.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TF1.h"
#include "TAxis.h"
#include "statistica.h"

using namespace std;

int main() {

	TApplication app("app", 0, 0);
	vector<double> theta0;
	vector<double> theta1;
	vector<double> theta2;

	vector<double> A_misurati;
	vector<double> B_misurati;
	vector<double> d1;
	vector<double> d2;
	vector<double> N1;
	vector<double> N2;

	vector<double> delta1;
	vector<double> delta2;
	vector<double> deltaN1;
	vector<double> deltaN2;
	vector<double> scartoA;
	vector<double> scartoB;
	vector<double> medie;
	EsperimentoPrisma myExp;
	fstream fileout1, fileout2, fileout3;

	double corrAB, corrN1N2, corrD1D2;


	fileout1.open("Angoli.dat", ios::out);
	if (!fileout1.good())
		cerr << "errore apertura file integrali.dat" << endl;

	fileout2.open("Parametri.dat", ios::out);
	if (!fileout2.good())
		cerr << "errore apertura file integrali.dat" << endl;

	fileout3.open("Indici di rifrazione", ios::out);
	if (!fileout3.good())
		cerr << "errore apertura file integrali.dat" << endl;		



//eseguo le misurazioni dell'esperimento, analizzo i risulatti per ricavare i parametri
	for(int i = 0; i<10000; i++) {
		myExp.Esegui();
		theta0.push_back(myExp.GetTh0misurato());
		theta1.push_back(myExp.GetTh1misurato());
		theta2.push_back(myExp.GetTh2misurato());
		myExp.Analizza();

		A_misurati.push_back(myExp.GetAmisurato());
		B_misurati.push_back(myExp.GetBmisurato());

		d1.push_back(myExp.GetDM1misurato());
		d2.push_back(myExp.GetDM2misurato());

		N1.push_back(myExp.GetN1misurato());
		N2.push_back(myExp.GetN2misurato());


		delta1.push_back((myExp.GetDM1misurato() - myExp.GetDM1input()));
		delta2.push_back((myExp.GetDM2misurato() - myExp.GetDM2input()));

		deltaN1.push_back((myExp.GetN1input()-myExp.GetN1misurato()));
		deltaN2.push_back((myExp.GetN2input()-myExp.GetN2misurato()));

		scartoA.push_back((myExp.GetAmisurato()-myExp.GetAinput()));
		scartoB.push_back((myExp.GetBmisurato()-myExp.GetBinput()));
	}



//creo gli istogrammi per gli angoli misurato con il metoodo esegui
	TH1F * Theta0 = new TH1F("Theta0", "Theta 0", 100, 1.5694, 1.572);
	Theta0->StatOverflows( kTRUE );
	for (int i=0; i<theta0.size(); i++)
		Theta0->Fill(theta0[i]);

	TH1F * Theta1 = new TH1F("Theta1", "Theta 1", 100, 2.53, 1.55);
	Theta1->StatOverflows( kTRUE );
	for (int i=0; i<theta1.size(); i++)
		Theta1->Fill(theta1[i]);

	TH1F * Theta2 = new TH1F("Theta2", "Theta 2", 100, 2.6552, 2.6581);
	Theta2->StatOverflows( kTRUE );
	for (int i=0; i<theta2.size(); i++)
		Theta2->Fill(theta2[i]);

	TCanvas *c1 = new TCanvas("Distribuzione θ misurati", "Distribuzione θ misurati");
	c1->Divide(3,1);
	c1->cd(1);
	Theta0->GetXaxis()->SetTitle("valori θ 0 [rad]");
	Theta0->GetYaxis()->SetTitle("frequenza");
	Theta0->Draw();
	c1->cd(2);
	Theta1->GetXaxis()->SetTitle("valori θ 1 [rad]");
	Theta1->GetYaxis()->SetTitle("frequenza");
	Theta1->Draw();
	c1->cd(3);
	Theta2->GetXaxis()->SetTitle("valori θ 2 [rad]");
	Theta2->GetYaxis()->SetTitle("frequenza");
	Theta2->Draw();


//creo gli istogrammi per valutare lo scarto tra i valori attesi e i valori misurati

	//ANGOLI DI DEVIAZIONE
	TH1F * Delta1 = new TH1F("Delta1", "δm(λ1)", 100, -0.002, 0.002);
	Delta1->StatOverflows( kTRUE );
	
	TH1F * Delta2 = new TH1F("Delta2", "δm(λ2)", 100, -0.002, 0.002);
	Delta2->StatOverflows( kTRUE );

	TH2F * Delta12 = new TH2F("Delta12", "Residui δm(λ1) e δm(λ2) misurati", 100, -0.002, 0.002, 100, -0.002, 0.002);
	

	//INDICI DI RIFRAZIONE per le due lunghezze d'onda
	TH1F * DeltaN1 = new TH1F("DeltaN1", "Scarto n(λ1)", 100, -0.001, 0.001);
	DeltaN1->StatOverflows( kTRUE );
	
	TH1F * DeltaN2 = new TH1F("DeltaN2", "Scarto n(λ2)", 100, -0.001, 0.001);
	DeltaN2->StatOverflows( kTRUE );

	TH2F * DeltaN1N2 = new TH2F("DeltaN1N2", "Residui n(λ1) e n(λ2) misurati", 100, -0.001, 0.001, 100, -0.001, 0.001);


	//PARAMETRI A e B
	TH1F * ScartoA =new TH1F("ScartoA", "ScartoA", 100, -0.005, 0.005 );
	ScartoA->StatOverflows( kTRUE );

	TH1F * ScartoB =new TH1F("ScartoB", "ScartoB", 100, -1E-15, 1E-15 );
	ScartoB->StatOverflows( kTRUE );

	TH2F * ScartoAB = new TH2F("ScartoAB", "Residui A e B misurati", 100, -0.005, 0.005, 100, -1E-15, 1E-15);

	//riempimento istogrammi

	for (int i=0; i<10000; i++) {
		Delta1->Fill(delta1[i]);
		Delta2->Fill(delta2[i]);
		Delta12->Fill(delta1[i], delta2[i]);
		DeltaN1->Fill(deltaN1[i]);
		DeltaN2->Fill(deltaN2[i]);
		DeltaN1N2->Fill(deltaN1[i], deltaN2[i]);
		ScartoA->Fill(scartoA[i]);
		ScartoB->Fill(scartoB[i]);
		ScartoAB->Fill(scartoA[i], scartoB[i]);
	}	


	//PLOT DISTRIBUZIONE SCARTI δm(λ1) e δm(λ2)
	TCanvas *c2 = new TCanvas("Distribuzione scarti δm(λ1) e δm(λ2)", "Distribuzione scarti δm(λ1) e δm(λ2)");
	c2->Divide(3,1);
	c2->cd(1);
	Delta1->GetXaxis()->SetTitle("Scarto δm(λ1) [rad]");
	Delta1->GetYaxis()->SetTitle("frequenza");
	Delta1->Draw();
	c2->cd(2);
	Delta2->GetXaxis()->SetTitle("Scarto δm(λ2) [rad]");
	Delta2->GetYaxis()->SetTitle("frequenza");
	Delta2->Draw();
	c2->cd(3);
	Delta12->GetXaxis()->SetTitle("Scarto δm(λ1) [rad]");
	Delta12->GetYaxis()->SetTitle("Scarto δm(λ2) [rad]");
	Delta12->Draw();


	//PLOT DISTRIBUZIONE SCARTI n(λ1) e n(λ2)
	TCanvas *c3 = new TCanvas("Distribuzione scarti n(λ1) e n(λ2)", "Distribuzione scarti n(λ1) e n(λ2)");
	c3->Divide(3,1);
	c3->cd(1);
	DeltaN1->GetXaxis()->SetTitle("Scarto n(λ1)");
	DeltaN1->GetYaxis()->SetTitle("frequenza");
	DeltaN1->Draw();
	c3->cd(2);
	DeltaN2->GetXaxis()->SetTitle("Scarto n(λ2)");
	DeltaN2->GetYaxis()->SetTitle("frequenza");
	DeltaN2->Draw();
	c3->cd(3);
	DeltaN1N2->GetXaxis()->SetTitle("Scarto n(λ1)");
	DeltaN1N2->GetYaxis()->SetTitle("Scarto n(λ2)");
	DeltaN1N2->Draw();


	//PLOT DISTRIBUZIONE SCARTI A e B
	TCanvas *c4 = new TCanvas("Distribuzione scarti A e B", "Distribuzione scarti A e B");
	c4->Divide(3,1);
	c4->cd(1);
	ScartoA->GetXaxis()->SetTitle("Scarto A");
	ScartoA->GetYaxis()->SetTitle("frequenza");
	ScartoA->Draw();
	c4->cd(2);
	ScartoB->GetXaxis()->SetTitle("Scarto B [m^2]");
	ScartoB->GetYaxis()->SetTitle("frequenza");
	ScartoB->Draw();
	c4->cd(3);
	ScartoAB->GetXaxis()->SetTitle("Scarto A");
	ScartoAB->GetYaxis()->SetTitle("Scarto B [m^2]");
	ScartoAB->Draw();

	corrAB = CalcolaCorrelazione(A_misurati, B_misurati);
	corrD1D2 = CalcolaCorrelazione(d1, d2);
	corrN1N2 = CalcolaCorrelazione(N1, N2);

	cout << "correlazione AB: " << corrAB << endl;
	cout << "correlazione d1 d2: " << corrD1D2 << endl;
	cout << "correlazione N1 N2: " << corrN1N2 << endl;

	for(int i=0; i<10000; i++) {
		fileout1 << setw(10) << theta0[i] << setw(10) << theta1[i] << setw(10) << theta2[i] << endl;
		fileout2 << setw(15) << A_misurati[i] << setw(15) << B_misurati[i] << endl;
		fileout3 << setw(10) << N1[i] << setw(10) << N2[i] << endl;
	}

	fileout2.close();
	fileout1.close();
	app.Run();

return 0;
}
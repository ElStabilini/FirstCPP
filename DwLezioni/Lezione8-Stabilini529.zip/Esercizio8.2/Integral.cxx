#ifndef __Integral_h__
#define __Integral_h__

#include <cmath>
#include <iomanip>

#include "iostream"
#include "Integral.h"
#include "Funzioni.h"

using namespace std;


double Midpoint::IntegraNstep(unsigned nstep) {
	m_h = (m_b - m_a)/double(nstep);
  m_sum = 0.;

  for (unsigned int i=0; i<nstep-1; i++){
    m_sum += m_f->Eval( m_a + (i+0.5)*m_h );
  }	

  m_integral = m_sign*m_sum*m_h;
  return m_integral;
};

double Simpson::IntegraNstep(unsigned nstep) {

	m_h = (m_b - m_a)/double(nstep);
  m_sum = 0.;

	double sum1 = 0;
	double sum2 = 0;

	for (unsigned int i=1; i<nstep-1; i++) {
		if(i%2 == 0)
			sum1 += 4*m_f->Eval(m_a + (i*m_h));
		else sum2 += 2*m_f->Eval(m_a + (i*m_h));
	}

	m_sum = sum1 + sum2;
	double f0 = m_f->Eval(m_a);
	double fn = m_f->Eval(m_b);
	m_integral = m_sign*(m_h/3)*(f0 + m_sum + fn);
	
};

double Trapezi::IntegraNstep(unsigned nstep) {
	m_h = (m_b - m_a)/double(nstep);
  m_sum = 0.;

	for (unsigned int i=0; i<nstep-1; i++){
    m_sum += m_f->Eval(m_a + i*m_h);
  }	

	double fa = m_f->Eval(m_a);
	double fb = m_f->Eval(m_b);

	m_integral = m_sign*(0.5*fa + m_sum + 0.5*fb)*m_h;
  return m_integral;

};


double Trapezi::IntegraPrec(double prec) {

	//controllo la precisione inserita
	double limit = 1E-8;
	if (prec < limit) {
		cout << "precision limit: " << limit << endl;
		exit(-3);
	}

	cout << "starting" << endl;
	unsigned int nstep = 8; 
	double I_h = IntegraNstep(nstep);
	cout << "Ih = " << I_h << endl;
	double I_hm = IntegraNstep(nstep*2);
	cout << "Ihm = " << I_hm << endl;

	m_h = (m_b - m_a)/double(nstep);

	double new_h = sqrt((prec*3*(pow(m_h, 2)))/(4*fabs(I_h - I_hm)));

	double n = (m_b - m_a)/new_h; 
	int new_nstep = (int)n;
	cout << "nuovi step: " << new_nstep << endl;

	if(new_nstep < 2) {
		return m_integral = IntegraNstep(nstep);
	} else {
		m_integral = IntegraNstep(new_nstep);
		return m_integral;	 
	}

};

#endif



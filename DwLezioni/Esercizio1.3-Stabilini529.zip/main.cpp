// =====================================================================           
// esercizio1.2.cxx : Esempio di codice per                                        
//       - leggere un set di dati da file                                          //       - calcolare la media                                                      //       - calcolare la mediana                                                    //                                                                                // note: - i dati da leggere sono semplici double. Usiamo un contenitore           //         di dati molto semplice, l'array del c                                   //       - cerchiamo di raggruppare il codice in un set di funzioni e 
//         portarle in un file esterno.
//                                                                           
// =====================================================================  

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>

// il file funzioni.h contiene la dichiarazione dei tipi delle funzioni
// che verranno utilizzate. L'implementazione delle funzioni ( dentro
// funzioni.cxx ) viene compilata a parte e fornita al programma principale
// in fase di linking ( nel Makefile )

#include "funzioni_vettori.h"
#include "funzioni_stat.h"

// =====================================================================
// incomincia il programma principale 
// =====================================================================

int main ( int argc , char** argv) {

  if ( argc < 3 ) {
    cout << "Uso del programma : " << argv[0] << " <n_data> <filename> " << endl;
    return -1 ;
  }

//  int ndata = 100 ;
  int ndata = atoi(argv[1]);
  char * filename = argv[2];

  // carico i dati da file
  double * data = ReadDataFromFile ( filename, ndata ) ;

  // Visualizzo dati caricati 
  cout << "Dati caricati" << endl;
  Print(data, ndata);

  // Calcolo la media e la varianza
  cout << "Media = " << CalcolaMedia( data , ndata ) << endl;
  cout << "Varianza = " << CalcolaVarianza( data , ndata ) << endl;

  
  //creo una copia del vettore
  double * copy = CopyVec(data, ndata);

  // Calcola la mediana
  cout << "Mediana = " << CalcolaMediana(copy, ndata)<< endl;
  
  // Scrivo i dati e i dati riordinati su file
  Print( "fileout.txt", data, ndata ) ;
  
  //controllo che i dati caricati non siano stati modificati
  cout << "dati originali" << endl;
  Print(data,ndata);
  cout << endl;

  //stampo il vettore ordinato
  cout << "vettore ordinato" << endl;
  Print(copy, ndata);

  delete [] copy;
  delete [] data;
  return 0;

}
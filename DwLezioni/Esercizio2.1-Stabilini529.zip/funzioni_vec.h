#ifndef __funzioni_vec_h__
#define __funzioni_vec_h__

#include <iostream>
#include <fstream> 
#include <cstdlib>
#include <cmath>
#include "Vettore.h"

using namespace std;

Vettore ReadDataFromFile (const char*  ,int );

void Vettore_selection_sort(Vettore&);
void PrintOnFile ( const char* , const Vettore & ); //sovrascrive il file
void PrintOnScreen(const Vettore &); //stampa su schermo

#endif // __funzioni_vec_h__

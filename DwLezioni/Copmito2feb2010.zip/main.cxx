#include "Esperimento.h"

#include <cmath>
#include <vector>
#include <iostream>
#include <cstdlib>
#include <fstream>

#define _USE_MATH_DEFINES

#include "TApplication.h"
#include "TCanvas.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TF1.h"
#include "TAxis.h"
#include "statistica.h"

using namespace std;

int main() {

	TApplication app("app", 0, 0);
	Esperimento myExp;
	vector<double> cx;
	vector<double> mx;

	RandomGen mygen(1);
	
	//TH1F * m = new TH1F("M", "M", 100, 5, 45);
	
	for(int i = 0; i<1000; i++) {
		myExp.Esegui();
		myExp.Analizza();
		cx.push_back(myExp.GetCxmisurato());
	}


	TH1F * CaloreSpecifico = new TH1F("calore specifico", "calore specifico", 100, 0.02, 0.18);
	CaloreSpecifico->StatOverflows( kTRUE );
	for (int i=0; i<cx.size(); i++)
		CaloreSpecifico->Fill(cx[i]);

	TCanvas *c1 = new TCanvas("Calore Specifico", "Calore Specifico");
	c1->cd();
	CaloreSpecifico->GetXaxis()->SetTitle("valori cx [cal/g °C]");
	CaloreSpecifico->GetYaxis()->SetTitle("frequenza");
	CaloreSpecifico->Draw();

	cout << "calore specifico vero = " << myExp.GetCxinput() << endl;
	cout << "calore specifico misurato = " << CalcolaMedia(cx) << endl;
	cout << "errore  = " << CalcolaDev(cx) << endl;

	vector<double> sigma = myExp.FonteErrore(1000);
	for (int i=0; i<sigma.size(); i++)
		cout << sigma[i] << endl;

	app.Run();
	return 0;
}
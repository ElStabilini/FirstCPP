//DEFINISCO LE FUNZIONI DA USARE CON LA CLASSE POSIZIONE
#include <iostream>
#include <fstream>
#include <vector>
#include"posizione.h"

//quello che devo fare con questa funzione è riordinare i punti in maniera da trovare il percorso più veloce
template <typename T> void BestPath (T start, T end ) {
	//il percorso dovrà congiungere due punti diversi tra loro quindi avrà partenza e arrivo (eventualmente diverso da quello dichiarato) e dovrà collegarli in modo da ottimizzare lo spostamento
	posizione rif (0,0,0); //io sicuramente partirò dall'origine
	for (auto it = start; it != end; it++) {
		sort (it, end, [&] (posizione i, posizione j) {return i.GetDistance(rif) < j.GetDistance(rif);});
	//ho definito una funzione lambda in cui
	//gli argomenti che prende dal main sono presi per riferimento
	//definisce che criterio usare per capire quale tra due punti è più vicino (come una qualunque if di un sort mi restituisce uno statement di verità)
	//una volta fatto questo voglo che il punto più vicino diventi il mio nuovo punto di riferimento
	rif = *it ;
	} 
}

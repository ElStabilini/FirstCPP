
#include "Vettore.h"
#include <iomanip>
#include <cmath>
#include <cstdlib>

//#define NDEBUG 

#include <assert.h> //mi consente di far abortire il programma se lo statement non è vero

// costruttore senza argomenti

Vettore::Vettore()  {
  cout << "Calling default constructor" << endl;
  m_N = 0;
  m_v = NULL;
}

// costruttore con dimensione
Vettore::Vettore(unsigned int N) {
  cout << "Calling constructor with arguments" << endl;
  m_N = N;
  m_v = new double[N];
  for ( int k = 0 ; k < N ; k++ ) 
		m_v[k] = 0;
  
}

//consente di accedere a una cella e modificcarne il contenuto
void Vettore::SetComponent(unsigned int i, double a) {
	//assert( ( m_N > i ) && "Errore : l'indice e' troppo grande");
  if ( i<m_N ) {
    m_v[i]=a;
  } else {
    cerr << "Errore: indice " << i << ", dimensione " << m_N << endl;
    exit (-1);
  }
}

//consente di accedere a una cella e verificarne il contenuto
double Vettore::GetComponent(unsigned int i) const {
  //assert( ( m_N > i ) && "Errore : l'indice e' troppo grande");
	if (i < m_N) {
		return m_v[i];
	} else { 
		cerr << "Errore: indice " << i << ", dimensione " << m_N << endl;
    exit (-1);
	}
}

void Vettore::Scambia(unsigned int i, unsigned int j) {
	//assert( ( m_N > i ) && "Errore : l'indice e' troppo grande");
	//assert( ( m_N > j ) && "Errore : l'indice e' troppo grande");
	double temp = GetComponent(i);
	SetComponent(i, GetComponent(j));
	SetComponent(j, temp);
}

double& Vettore::operator[] (unsigned int i) {
	//assert( ( m_N > i ) && "Errore : l'indice e' troppo grande");
	if (i < m_N) {
		return m_v[i];
	} else { 
		cerr << "Errore: indice " << i << ", dimensione " << m_N << endl;
    exit (-1);
	}
}
//restituisce un & perchè questo metodo non è dichiarato costante quindi posso intenderlo sia per accedere al contenuto del mio vettore sia per la sua modifica, in questo caso è ovvio che se lo voglio modificare voglio che questa modifica valga anche nel main e ogni volta che userò il vettore quindi poi con il & mi restituisce il vettore con la modifica che ho fatto

//definisco il distruttore
Vettore::~Vettore() {
	cout << "Calling destructor" << endl;
	delete [] m_v;
}

//definisco il copy constructor
Vettore::Vettore(const Vettore& V) {
	m_N = V.GetN();
	//per definire un nuovo elemento della classe di questo elemento devo definire i parametri private
	m_v = new double[m_N];
	for (int i=0; i<m_N; i++) //la dimensione del nuovo vettore verrà presa dalla dimensione del vettore di partenza
		m_v[i]=V.GetComponent(i);
}

//definisco l'operatore di assegnazione della classe vettore

Vettore& Vettore::operator=(const Vettore& V) {
	m_N = V.GetN();
	if (m_v) //se esiste questo
		delete[] m_v; //lo dealloco
	m_v = new double[m_N]; //a questo punto posso partire con la creazione di quello nuovo perchè sono sicura che se prima c'era qualcosa l'ho cancellato
	for (int i=0; i < m_N; i++)
		m_v[i] = V.GetComponent(i);
	return *this;
}
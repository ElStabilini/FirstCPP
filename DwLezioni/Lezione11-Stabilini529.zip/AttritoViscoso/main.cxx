#include "AttritoViscoso.h"

#include <cmath>
#include <vector>
#include <iostream>
#include <cstdlib>
#include <fstream>

#define _USE_MATH_DEFINES

#include "TApplication.h"
#include "TCanvas.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TF1.h"
#include "TAxis.h"
#include "statistica.h"

using namespace std;

int main() {

	TApplication app("app", 0, 0);
	AttritoViscoso myExp;
	vector<double> eta1;
	vector<double> eta2;
	vector<double> eta;
	vector<double> etaR;
	vector<double> etaT;
	vector<double> etaX;

	for(int i = 0; i<1000; i++) {
		myExp.Esegui();
		myExp.Analizza();
		eta.push_back(myExp.GetEta1misurato());
		eta.push_back(myExp.GetEta2misurato());
		eta1.push_back(myExp.GetEta1misurato());
		eta2.push_back(myExp.GetEta2misurato());
	}

	/*TH1F * Eta1 = new TH1F("Eta 1", "Eta 1", 100, 0.7, 0.9);
	Eta1->StatOverflows( kTRUE );
	for (int i=0; i<eta1.size(); i++)
		Eta1->Fill(eta1[i]);

	TH1F * Eta2 = new TH1F("Eta 2", "Eta 2", 100, 0.7, 0.9);
	Eta2->StatOverflows( kTRUE );
	for (int i=0; i<eta2.size(); i++)
		Eta2->Fill(eta2[i]);*/

	TH1F * Eta = new TH1F("Eta", "Eta", 100, 0.74, 0.94);
	Eta->StatOverflows( kTRUE );
	for (int i=0; i<eta1.size(); i++)
		Eta->Fill(eta1[i]);

	TCanvas *c1 = new TCanvas("Valori coeff. attrito viscoso", "Valori coeff. attrito viscoso");
	/*c1->Divide(3,1);
	c1->cd(1);
	Eta1->GetXaxis()->SetTitle("valori eta [1/m*s]");
	Eta1->GetYaxis()->SetTitle("frequenza");
	Eta1->Draw();
	c1->cd(2);
	Eta2->GetXaxis()->SetTitle("valori eta [1/m*s]");
	Eta2->GetYaxis()->SetTitle("frequenza");
	Eta2->Draw();
	c1->cd(3);*/
	c1->cd();
	Eta->GetXaxis()->SetTitle("valori eta [1/m*s]");
	Eta->GetYaxis()->SetTitle("frequenza");
	Eta->Draw();

	cout << "eta vero = " << myExp.GetEtainput() << endl;
	cout << "eta da sfera1 = " << CalcolaMedia(eta1) << endl;
	cout << "eta da sfera2 = " << CalcolaMedia(eta2) << endl;

	//per valutare qual è la fonte d'errore che contribuisce maggiormente valuto il valore di eta ottenuto considerando una fonte d'errore per volta

	//valuto il contributo R
	/*myExp.SetSigmaR(0.0001);
	myExp.SetSigmaT(0);
	myExp.SetSigmaX(0);
	for(int i = 0; i<1000; i++) {
		myExp.Esegui();
		myExp.Analizza();
		etaR.push_back(myExp.GetEta1misurato());
		etaR.push_back(myExp.GetEta2misurato());
	}
	cout << "Eta con contributo di R" << CalcolaMedia(etaR) << endl;

//valuto il contributo R
	myExp.SetSigmaR(0);
	myExp.SetSigmaT(0.01);
	myExp.SetSigmaX(0);
	for(int i = 0; i<1000; i++) {
		myExp.Esegui();
		myExp.Analizza();
		etaR.push_back(myExp.GetEta1misurato());
		etaR.push_back(myExp.GetEta2misurato());
	}
	cout << "Eta con contributo di T" << CalcolaMedia(etaT) << endl;
	
	//valuto il contributo R
	myExp.SetSigmaR(0);
	myExp.SetSigmaT(0);
	myExp.SetSigmaX(0.001);
	for(int i = 0; i<1000; i++) {
		myExp.Esegui();
		myExp.Analizza();
		etaR.push_back(myExp.GetEta1misurato());
		etaR.push_back(myExp.GetEta2misurato());
	}
	cout << "Eta con contributo di X" << CalcolaMedia(etaX) << endl;*/

	app.Run();
	return 0;
}
#include <cmath>
#include <vector>
#include "Esperimento.h"
#include "RandomGen.h"
#include "statistica.h"

#define _USE_MATH_DEFINES

Esperimento::Esperimento():
	m_gen(1),
	m_ma_input(150),
	m_sigma_ma(2.),
	m_ca(1),
	m_TA_input(16.1),
	m_sigma_TA(0.2),
	m_mc(27.737),
	m_TC_input(90.6),
	m_sigma_TC(0.4),
	m_TE_input(17.2),
	m_sigma_TE(0.2),
	m_m_input(25.0),
	m_sigma_m(5.0)
{
	m_cx_input = ((m_ma_input + m_m_input)*m_ca*(m_TE_input-m_TA_input))/(m_mc*(m_TC_input-m_TE_input));

};

//implemento il metodo esegui (metodo che mi restituisce le misure simulate)
void Esperimento::Esegui() {
	m_m_misurato = m_gen.Gauss(m_m_input, m_sigma_m);
	m_ma_misurato = m_gen.Gauss(m_ma_input, m_sigma_ma);
	m_TE_misurato = m_gen.Gauss(m_TE_input, m_sigma_TE);
	m_TA_misurato = m_gen.Gauss(m_TA_input, m_sigma_TA);
	m_TC_misurato = m_gen.Gauss(m_TC_input, m_sigma_TC);
};


//il metodo analizza, dai tre angoli che sono stati misurati con il metodo esegui ricavo gli angoli di deviazione e i valori di A e B che otterrei con queste misure
void Esperimento::Analizza() {
	m_cx_misurato = ((m_ma_misurato + m_m_misurato)*m_ca*(m_TE_misurato-m_TA_misurato))/(m_mc*(m_TC_misurato-m_TE_misurato));
}

vector<double> Esperimento::FonteErrore(int measures) {
	
	double Ma = GetSigmaMa(); 
	double Ta = GetSigmaTa(); 
	double Tc = GetSigmaTc(); 
	double Te = GetSigmaTe(); 
	double M = GetSigmaM();

	vector<double> contributoMa;
	vector<double> contributoTa;
	vector<double> contributoTc;
	vector<double> contributoTe;
	vector<double> contributoM;

	SetSigmaMa(0);
	SetSigmaTa(0);
	SetSigmaTc(0);
	SetSigmaTe(0);
	SetSigmaM(0);

	//contributo Ma
	SetSigmaMa(Ma);
	for (int i=0; i< measures; i++) {
		Esegui();
		m_cx_misurato = ((m_ma_misurato + m_m_input)*m_ca*(m_TE_input-m_TA_input))/(m_mc*(m_TC_input-m_TE_input));
		contributoMa.push_back(GetCxmisurato());
	}
	SetSigmaMa(0);

	//contributo Ta
	SetSigmaTa(Ta);
	for (int i=0; i< measures; i++) {
		Esegui();
		m_cx_misurato = ((m_ma_input + m_m_input)*m_ca*(m_TE_input-m_TA_misurato))/(m_mc*(m_TC_input-m_TE_input));
		contributoTa.push_back(GetCxmisurato());
	}
	SetSigmaTa(0);

	//contributo TC
	SetSigmaTc(Tc);
	for (int i=0; i< measures; i++) {
		Esegui();
		m_cx_misurato = ((m_ma_input + m_m_input)*m_ca*(m_TE_input-m_TA_input))/(m_mc*(m_TC_misurato-m_TE_input));
		contributoTc.push_back(GetCxmisurato());
	}
	SetSigmaTc(0);

	//contributo Te
	SetSigmaTe(Te);
	for (int i=0; i< measures; i++) {
		Esegui();
		m_cx_misurato = ((m_ma_input + m_m_input)*m_ca*(m_TE_misurato-m_TA_input))/(m_mc*(m_TC_input-m_TE_misurato));
		contributoTe.push_back(GetCxmisurato());
	}
	SetSigmaTe(0);

	//contributo M
	SetSigmaM(M);
	for (int i=0; i< measures; i++) {
		Esegui();
		m_cx_misurato = ((m_ma_input + m_m_misurato)*m_ca*(m_TE_input-m_TA_input))/(m_mc*(m_TC_input-m_TE_input));
		contributoM.push_back(GetCxmisurato());
	}
	SetSigmaM(0);

	vector<double> dev;
	dev.push_back(CalcolaDev(contributoMa));
	cout << "deviazione standard solo Ma: " << CalcolaDev(contributoMa) << endl;
	
	dev.push_back(CalcolaDev(contributoTa));
	cout << "Deviazione standard solo Ta: " << CalcolaDev(contributoTa) << endl;
	
	dev.push_back(CalcolaDev(contributoTc));
	cout << "Deviazione standard solo Tc: " << CalcolaDev(contributoTc) << endl;
	
	dev.push_back(CalcolaDev(contributoTe));
	cout << "Deviazione standard solo Te: " << CalcolaDev(contributoTe) << endl;
	
	dev.push_back(CalcolaDev(contributoM));
	cout << "Deviazione standard solo M: " << CalcolaDev(contributoM) << endl;

	
	cout << "correlazione tra Ma e M: " << CalcolaCorrelazione(contributoMa, contributoM) << endl;
	cout << "correlazione tra Ta e Te:" << CalcolaCorrelazione(contributoTa, contributoTe) << endl;
	cout << "correlazione tra Ta e Tc: " << CalcolaCorrelazione(contributoTa, contributoTc) << endl;
	cout << "correlazione tra Te e Tc:" << CalcolaCorrelazione(contributoTc, contributoTe) << endl; 

	return dev;
}
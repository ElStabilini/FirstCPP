#include "funzioni_stat.h"
#include "funzioni_vettori.h"

double CalcolaMedia( double * data , int size ) {
    double sum = 0;
	  for (int i=0; i<size; i++)
		  sum = sum + data[i];
	return sum/size;
  
}

double CalcolaVarianza( double * data , int size ) {
 double scarto = 0;
  for (int i=0; i<size; i++)
    scarto = scarto + pow(data[i] - CalcolaMedia(data, size), 2);
  return scarto/size;

}
                                 
// Calcolo della mediana di un array <vec> di dimensione <size>. Prima si crea
// una copia dell'array, lo riordina e calcola la mediana

double CalcolaMediana ( double vec[] , int size ) {
  double mediana = 0;
 
  //CopyVec(vec, size);
  double n=size/2;
  int x = (int)n;
  selection_sort(vec, size); //riordino il vettore copiato

    if (size%2 == 0) {  //se hai un numero pari di dati fai la media tra i due valori centrali
    mediana = (vec[x+1]+vec[x-1])/2;
      } else {       //se il numero di dati è dispari restituisce il valore centrale
    mediana = vec[x];
    }
  return mediana;
} 
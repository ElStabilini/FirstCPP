#include <iostream>
#include <cmath>
#include <iomanip>
#define _USE_MATH_DEFINES


#include "Funzioni.h"
#include "Integral.h"

#include "TH1F.h"
#include "TApplication.h"
#include "TCanvas.h"
#include "TGraph.h"

using namespace std;

int main(int argc, const char ** argv){

	TApplication app("app",0,0);
  
  if (argc != 2) {
    cout << "Usage: ./main nstep" << endl;
    return -1;
  }

  double a = 0.;
  double b = M_PI;

  int nstep = atoi(argv[1]);

  FunzioneBase* sinx = new Coseno(1, 1, - M_PI/2, 0);
	Integratore* mySimpson = new Simpson(a,b,sinx);
	Integratore* myMidpoint = new Midpoint(a,b,sinx);

	sinx->Print();

	TGraph *gMidpoint = new TGraph();
	TGraph *gSimpson = new TGraph();

	
	cout << setw(10) <<"nstep" << setw(10) << "deltaSimp" << setw(10) << "deltaMid" << endl;

	int i=1E2;
	for(int k=0; k<20; k++) {

		double delta1 = fabs(2 - mySimpson->Integra(i));
		double h1 = mySimpson->GetH();
		cout << setw(10) << i << "  "<< setw(10) << delta1;
		gSimpson->SetPoint(k, log10(h1), log10(delta1));

		double delta2 = fabs(2 - myMidpoint->Integra(i));
		double h2 = myMidpoint->GetH();
		cout << setw(10) << delta2 << endl;
		gMidpoint->SetPoint(k, log10(h2), log10(delta2));

		i=2*i;
	}
	
	cout << setprecision(12) << mySimpson->Integra(nstep) <<endl;
	
	TCanvas * Plot = new TCanvas("Plot", "differenza", 500, 500); 
	Plot->cd();
	gSimpson->Draw("ACP"); 
	gSimpson->SetTitle("differenza integrale - approssimazione");
	gSimpson->GetXaxis()->SetTitle("GetH");
	gSimpson->GetYaxis()->SetTitle("delta");
	gSimpson->SetLineColor(2);

	gMidpoint->Draw("sameCP"); 
	gMidpoint->SetLineColor(3);
	
	delete[] sinx;
	delete[] myMidpoint;
	delete[] mySimpson;
 
  app.Run();
  return 0;
}


/*int k=0;
	for (int i=1; i<1000; i*=2) {
		double delta1 = fabs(2 - mySimpson->Integra(i));
		double h1 = mySimpson->GetH();
		//cout << setw(10) << i << "  "<< setw(10) << delta1;
		gSimpson->SetPoint(k, h1, delta1);
		k++;
	}*/
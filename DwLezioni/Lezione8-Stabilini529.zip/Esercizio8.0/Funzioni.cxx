#include "Funzioni.h"
#include <iostream>
#include <cmath>

/*
	IMPLEMENTAZIONE METODI PARABOLA 
*/

Parabola::Parabola()  {
	cout << "calling default constructor" << endl;
	m_a = 0; m_b = 0;	m_c = 0;
	};

Parabola::Parabola(double a, double b, double c) {
		cout << "calling construcr with arguments" << endl;
		m_a = a;
		m_b = b;
		m_c = c;
};

Parabola::Parabola(const Parabola& p)  {
		cout << "calling copy constructor" << endl;
		m_a = p.GetA();
		m_b = p.GetB();
		m_c = p.GetC();
	};


void Parabola::Print () const {
		cout << "f(x) = " << GetA() << "x^2 + " << GetB() << "x + " << GetC() << endl;
	};
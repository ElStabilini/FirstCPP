#include <iostream>
#include <fstream> 
#include <cstdlib>
#include <cmath>

using namespace std;

double * ReadDataFromFile ( const char*  , int ) ;

void scambiaByValue(double , double ) ;
void scambiaByRef(double &, double &) ;
void scambiaByPointer(double *, double *) ;

void selection_sort( double * , int );
void PrintOnFile ( const char* , double * , int ); //sovrascrive il file
double * CopyVec(double *,int );
void PrintOnScreen(double *, int ); //stampa su schermo
#include <iostream>
#include <cmath>
#include <string>
#include "Posizione.h"

using namespace std;

int main (int argc , char** argv) {

	if ( argc != 4 ) {
    cerr << "Uso del programma : " << argv[0] << " <x> <y> <z>" << endl;
    return -1 ;
  }

	double x = atoi(argv[1]);
	double y = atoi(argv[2]);
	double z = atoi(argv[3]);

	Posizione P(x, y, z);

	cout << "coordinate cartesiane" << endl;
	cout << "(" << P.getX() << ", " << P.getY() << ", " << P.getZ() << ")" << endl;
	cout << "coordinate sferiche" << endl;
	cout << "(" << P.getR() << ", " << P.getPhi() << ", " << P.getTheta() << ")" << endl;
	cout << "coordinate cilindriche" << endl;
	cout << "(" << P.getRho() << ", " << P.getPhi() << ", " << P.getZ() << ")" << endl; 



	return 0;
}
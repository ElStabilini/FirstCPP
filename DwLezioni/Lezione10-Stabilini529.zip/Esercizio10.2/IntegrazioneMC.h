#ifndef __INTEGRALEMC_H__
#define __INTEGRALEMC_H__

#include "RandomGen.h"
#include "Funzioni.h"
#include <cmath>
#include <vector>

using namespace std;

//creo una classe integrale che implementa i metodi di integrazione Montecarlo
class IntegraleMC {
	
public :

	//costruttore
	IntegraleMC(unsigned int seed);
	~IntegraleMC();

	//definisco i metodi di integrazione con il metodo della media 
	//metodo a numero di punti fissato
	double Media(const FunzioneBase* f, double xmin, double xmax, unsigned int punti);

	//metodo a precisione fissato
	double MediaFixedPrecGeneral(const FunzioneBase* f, double xmin, double xmax, double prec);
	
	//metodo a precisione fissata mediante il teorema del limite centrale
	double MediaFixedPrec(const FunzioneBase* f, double xmin, double xmax, double prec);

	//prende per argomento anche un vettore di stime già fatte dell'integrale
	template <typename T> double MediaFixedPrecGeneral(const FunzioneBase* f, double xmin, double xmax, double prec, const vector<T> v, double points);


	//definisco i metodi si integrazione di tipo HitMiss
	//metodo HitMiss per una funzione con massimo noto a numero di punti fissaato
	double HitMiss(const FunzioneBase *f, double xmin, double xmax, unsigned int punti);

	//dichiarazione metodo HitMiss per una funzione con massimo non noto a numero di punti fissato
	double HitMiss(const FunzioneBase *f, double xmin, double xmax, unsigned int punti, double M);

	//dichiarazione metodo HitMiss per una funzione con massimo noto a precisione fissata
	double HitMissFixedPrec(const FunzioneBase *f, double xmin, double xmax, double prec, double M);
	
	//prende per argomento anche un vettore di stime già fatte dell'integrale
	template <typename T> double HitMissFixedPrec(const FunzioneBase *f, double xmin, double xmax, double prec, double M, const vector<T> v, double points);
	
	//definisco dei metodi Get che mi restituiscono l'errore e il numero di punti
	double GetErrore() const {return m_errore;}
	unsigned int GetN() const {return m_punti;}

private :

	RandomGen m_gen;
	double m_errore;
	unsigned int m_punti;
};

#endif //__INTEGRALEMC_H__	
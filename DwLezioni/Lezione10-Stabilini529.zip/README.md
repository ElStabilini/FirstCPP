# Esercitazione 10
  
## Esercizi

La lezione di oggi prevede i seguenti esercizi, di cui due da consegnare:

-   10.0: generazione di numeri casuali usando diverse distribuzioni (**da consegnare**)
-   10.1: verifica del teorema del limite centrale
-   10.2: calcolo di integrali con metodi Monte Carlo (**da consegnare**)
-   10.3: calcolo di integrali multidimensionali
-   10.4: errori nel caso di integrali multidimensionali

Il testo completo degli esercizi si trova a [questo link](http://labmaster.mi.infn.it/Laboratorio2/labTNDS/lectures_1819/lezione10_1819.html).

Per questa esercitazione avrete bisogno di ROOT. Per scaricarlo nella vostra _main directory_ eseguite nella shell della finestra Repl di destra gli usuali comandi:
  * wget https://root.cern/download/root_v6.22.02.Linux-ubuntu18-x86_64-gcc7.5.tar.gz
  * tar -zxvf root_v6.22.02.Linux-ubuntu18-x86_64-gcc7.5.tar.gz
  * source setup.sh
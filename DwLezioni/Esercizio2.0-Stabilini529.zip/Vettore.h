
#ifndef __Vettore_h__
#define __Vettore_h__

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

class Vettore {

 public:

	Vettore();
	Vettore(unsigned int N); //costruttore con dimensione del Vettore

	//definisco il distruttore
	~Vettore();
	
	//definisco i metodi
	unsigned int GetN() const {return m_N;}  //accede e mi restituisce la dimensione del Vettore

	double GetComponent(unsigned int) const; //accede e restituisce il contenuto di una cella del Vettore
	
	void SetComponent(unsigned int, double);
	//accede a una cella del vettore e ne modifica il valore come mi serve

	void Scambia(unsigned int, unsigned int);

	//operatore reference - overloading di operatore d'accesso a una variabile -
	double& operator[](unsigned int i);

	//definisco il copy contructor
	Vettore(const Vettore&);

	//definisco un operatore di assegnazione della classe vettore
	Vettore& operator=(const Vettore&);	

 private:

	unsigned int m_N;
	double * m_v;

};

#endif // __Vettore_h__
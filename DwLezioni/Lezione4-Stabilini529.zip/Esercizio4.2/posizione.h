//Creo una classe posizione

#ifndef __posizione_h__
#define __posizione_h__

#include <iostream>
#include <cmath>
#include <string>

using namespace std;

class posizione {
                          
 public:
  
	posizione() {
		cout << "Calling default constructor" << endl;
  	m_x = 0; m_y = 0; m_z = 0;
  };
	
	posizione(double x, double y, double z) {
  	cout << "Calling constructor with arguments" << endl;
 	 	m_x = x;
		m_y = y;
		m_z = z;
  }; //costruttore con le posizioni che voglio

	//restituisce i valori delle componenti
	double GetX() const {return m_x;};
	double GetY() const {return m_y;};
	double GetZ() const {return m_z;};
	
	//modifica i valori delle componenti
	void SetX(double x) {m_x = x;};
	void SetY(double y) {m_y = y;};
	void SetZ(double z) {m_x = z;};

	friend std::istream& operator>>(std::istream& is , posizione& p ) {
    string temp;    
    std::getline(is, temp, ',' );
    p.m_x = std::stod(temp);
    std::getline(is, temp, ',' );
    p.m_y = std::stod(temp);
    std::getline(is, temp, '\n' );
    p.m_z = std::stod(temp);   
    return is;
  };

	void printPositions() {
		cout << "Posizione : x = " << m_x << " y = " << m_y << " z = " << m_z << endl;
	};

	double GetDistance() const {return sqrt( m_x*m_x + m_y*m_y + m_z*m_z);};

//creo un metodo che clacoli la mia distanza da un punto p
	double GetDistance(posizione p) const {
		double dx = p.GetX() - m_x; //sottraggo automaticamente la componente corrispondente della mia posizione perchè io voglio che questa venga calcolata dal punto in cui mi trovo io ora
		double dy = p.GetY() - m_y;
		double dz = p.GetZ() - m_z;
		return sqrt(dx*dx + dy*dy +dz*dz);
	};

//ridefinisco l'operatore di ordinamento
	bool operator < (const posizione & b) const {return (GetDistance() > b.GetDistance()); 
	};

//sto ridefinendo l'operatore gli sto solo spiegando come deve interpreatre una riga di codice in cui io gli dico che a > b (dove a e b sono due oggetti di tipo posizione)
 	private:
	double m_x, m_y, m_z;

};

#endif // __posizione_h__


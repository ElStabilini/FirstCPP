#include "funzioni_vettori.h"

void PrintOnFile ( const char* Filename, double * data, int size ) {
  ofstream outfile(Filename);
  if(!outfile) {
    cerr << "errore apertura file risultati.dat" << endl;
    exit(0);
  }
  
  for (int i=0; i<size; i++)
    outfile << data[i] << endl;
}

double * ReadDataFromFile ( const char* Filename , int size  ) {
 double * data = new double[size];
  cout <<"inizio apertura file"<< endl;
  ifstream infile(Filename);
  if (!infile) {
		cerr << "errore apertura file data.dat" << endl;
    exit(2);
  }

  for (int i = 0; i < size; i++) {
      infile >> data[i];
      if (infile.eof()) {
        cout << "fine dati da leggere" << endl;
        break;
      }
  }
  return data;
}

void scambiaByValue(double a, double b) {
  double tmp = a;
	a = b;
	b = tmp;
}

void scambiaByRef(double &a, double &b) {
 double tmp = a;
	a = b;
	b = tmp;
}

void scambiaByPointer(double *a, double *b) {
  double c = *a; //creo una variabile di tipo double a cui viene assegnato il valore puntato da a
	*a = *b; //alla variabile puntata da a viene aasegnato il valore puntato dalla variabile b
	*b = c; //alla variabile puntata da b viene assegnato il valore di c
}

void selection_sort( double * vec , int size) {
  for (int i=0; i < size; i++)
		  for (int j=0; j < size; j++)
			  if(vec[i] > vec[j]) {
				  double tmp = vec[i];
			  	vec[i] = vec[j];
				  vec[j] = tmp;
			  }         

}

double * CopyVec(double *vec,int size){
  double * copy = new double[size];
  for (int i=0; i< size; i++)
    copy[i] = vec[i];
  return copy;
}

void PrintOnScreen(double *vec, int size) {
  for (int i=0; i<size; i++)
    cout << vec[i] << endl;
}
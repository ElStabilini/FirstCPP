#ifndef _Esperimento_Prisma_h_
#define _Esperimento_Prisma_h

#include <cmath>
#include <vector>
#include "RandomGen.h"

using namespace std;

class Esperimento {

public :
	Esperimento(); //costruttore implementato nel .cxx
	~Esperimento() {;};

	void Esegui();
	void Analizza();
	//vector<double> FonteErrore(int measures);
	vector<double>EsperimentoCompleto(double nprove);

	double GetRINinput() {return m_Rin_input;};
	double GetRINmisurato() {return m_Rin_misurato;};
	double GetSigmaRIN() {return m_sigma_Rin;};
	double GetR1input() {return m_R1_input;};
	double GetR1misurato() {return m_R1_misurato;};
	double GetSigmaR1() {return m_sigma_R1;};
	double GetR2input() {return m_R2_input;};
	double GetR2misurato() {return m_R2_misurato;};
	double GetSigmaR2() {return m_sigma_R2;};
	double GetR3input() {return m_R3_input;};
	double GetR3misurato() {return m_R3_misurato;};
	double GetSigmaR3() {return m_sigma_R3;};

	void SetSigmaRIN(double Rin) {m_sigma_Rin = Rin;};
	void SetSigmaR1(double R1) {m_sigma_R1 = R1;};
	void SetSigmaR2(double R2) {m_sigma_R2 = R2;};
	void SetSigmaTe(double R3) {m_sigma_R3 = R3;};
	void SetSigma(double R1, double R2, double R3) {
		m_sigma_R1 = R1;
		m_sigma_R2 = R2;
		m_sigma_R3 = R3;
	}
	void SetSigma(double x) {
		m_sigma_R1 = x;
		m_sigma_R2 = x;
		m_sigma_R3 = x;
	}

private:

	RandomGen m_gen; //generatore di numeri casuali che viene dichiarato come datamembro privato perchè non deve cambiare fino alla fine "dell'esperimento" (il generatore deve aggiornare il seed di volta in volta in modo da restituire risultati diversi e non sempre lo stesso)

	double m_Rin_input, m_Rin_misurato;
	double m_sigma_Rin;
	double m_R1_input, m_R1_misurato;
	double m_sigma_R1;
	double m_R2_input, m_R2_misurato;
	double m_sigma_R2;
	double m_R3_input, m_R3_misurato;
	double m_sigma_R3;
};

#endif
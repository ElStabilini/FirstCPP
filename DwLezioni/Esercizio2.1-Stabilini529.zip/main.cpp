#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>

#include "funzioni_vec.h"
#include "funzioni_stat.h"
#include "Vettore.h"

int main ( int argc , char** argv) {

  if ( argc < 3 ) {
    cout << "Uso del programma : " << argv[0] << " <n_data> <filename> " << endl;
    return -1 ;
  }

	unsigned int ndata = atoi(argv[1]);
  char * filename = argv[2];

	//carico i dati da file
	Vettore data = ReadDataFromFile(filename, ndata);

	//visualizzo i dati caricati
	cout << "Dati caricati" << endl;
	PrintOnScreen(data);

	//calcolo media e varianza 
	cout << "Media = " << CalcolaMedia(data) << endl;
  cout << "Varianza = " << CalcolaVarianza(data) << endl;

	//creo una copia del Vettore
	Vettore copy = Vettore(data);

	//calcolo la mediana
	cout << "Mediana = " << CalcolaMediana(copy) << endl;

	//scrivo i dati ordinati su file
	PrintOnFile( "fileout.txt", data) ;

	//controllo che i dati caricati non siano stati modificati
  cout << "dati originali" << endl;
  PrintOnScreen(data);
  cout << endl;

	//stampo il vettore ordinato
  cout << "vettore ordinato" << endl;
  PrintOnScreen(copy);

	return 0;
}

#include <cmath>
#include <vector>
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <iomanip>

#include "Esperimento.h"
#include "RandomGen.h"
#include "statistica.h"

#define _USE_MATH_DEFINES

Esperimento::Esperimento():
	m_gen(1),
	m_Rin_input(59.),
	m_sigma_Rin(3.),
	m_R1_input(90.),
	m_sigma_R1(1.),
	m_R2_input(10.),
	m_sigma_R2(1.),
	m_R3_input(50.),
	m_sigma_R3(1.)
{
	m_Rin_input = (m_R1_input*m_R2_input + m_R2_input*m_R3_input + m_R1_input*m_R3_input)/(m_R1_input + m_R2_input);

};

//implemento il metodo esegui (metodo che mi restituisce le misure simulate)
void Esperimento::Esegui() {
	m_R1_misurato = m_gen.Gauss(m_R1_input, m_sigma_R1);
	m_R2_misurato = m_gen.Gauss(m_R2_input, m_sigma_R2);
	m_R3_misurato = m_gen.Gauss(m_R3_input, m_sigma_R3);
};


void Esperimento::Analizza() {
	m_Rin_misurato = (m_R1_misurato*m_R2_misurato + m_R2_misurato*m_R3_misurato + m_R3_misurato*m_R1_misurato)/(m_R1_misurato + m_R2_misurato);
}

vector<double>Esperimento::EsperimentoCompleto(double Nmisure) {
	vector<double> misure;

	for(int i=0; i<Nmisure; i++) {
		Esegui();
		Analizza();
		misure.push_back(GetRINmisurato());
	}

		cout << setw(15) << GetSigmaR1() << setw(15) << CalcolaMedia(misure) << setw(15) << CalcolaDev(misure)  << endl;


	return misure;
}

/*vector<double> Esperimento::FonteErrore(int measures) {
	
	double Ma = GetSigmaMa(); 
	double Ta = GetSigmaTa(); 
	double Tc = GetSigmaTc(); 
	double Te = GetSigmaTe(); 
	double M = GetSigmaM();

	vector<double> contributoMa;
	vector<double> contributoTa;
	vector<double> contributoTc;
	vector<double> contributoTe;
	vector<double> contributoM;

	SetSigmaMa(0);
	SetSigmaTa(0);
	SetSigmaTc(0);
	SetSigmaTe(0);
	SetSigmaM(0);

	//contributo Ma
	SetSigmaMa(Ma);
	for (int i=0; i< measures; i++) {
		Esegui();
		m_cx_misurato = ((m_ma_misurato + m_m_input)*m_ca*(m_TE_input-m_TA_input))/(m_mc*(m_TC_input-m_TE_input));
		contributoMa.push_back(GetCxmisurato());
	}
	SetSigmaMa(0);

	//contributo Ta
	SetSigmaTa(Ta);
	for (int i=0; i< measures; i++) {
		Esegui();
		m_cx_misurato = ((m_ma_input + m_m_input)*m_ca*(m_TE_input-m_TA_misurato))/(m_mc*(m_TC_input-m_TE_input));
		contributoTa.push_back(GetCxmisurato());
	}
	SetSigmaTa(0);

	//contributo TC
	SetSigmaTc(Tc);
	for (int i=0; i< measures; i++) {
		Esegui();
		m_cx_misurato = ((m_ma_input + m_m_input)*m_ca*(m_TE_input-m_TA_input))/(m_mc*(m_TC_misurato-m_TE_input));
		contributoTc.push_back(GetCxmisurato());
	}
	SetSigmaTc(0);

	//contributo Te
	SetSigmaTe(Te);
	for (int i=0; i< measures; i++) {
		Esegui();
		m_cx_misurato = ((m_ma_input + m_m_input)*m_ca*(m_TE_misurato-m_TA_input))/(m_mc*(m_TC_input-m_TE_misurato));
		contributoTe.push_back(GetCxmisurato());
	}
	SetSigmaTe(0);

	//contributo M
	SetSigmaM(M);
	for (int i=0; i< measures; i++) {
		Esegui();
		m_cx_misurato = ((m_ma_input + m_m_misurato)*m_ca*(m_TE_input-m_TA_input))/(m_mc*(m_TC_input-m_TE_input));
		contributoM.push_back(GetCxmisurato());
	}
	SetSigmaM(0);

	vector<double> dev;
	dev.push_back(CalcolaDev(contributoMa));
	cout << "deviazione standard solo Ma: " << CalcolaDev(contributoMa) << endl;
	
	dev.push_back(CalcolaDev(contributoTa));
	cout << "Deviazione standard solo Ta: " << CalcolaDev(contributoTa) << endl;
	
	dev.push_back(CalcolaDev(contributoTc));
	cout << "Deviazione standard solo Tc: " << CalcolaDev(contributoTc) << endl;
	
	dev.push_back(CalcolaDev(contributoTe));
	cout << "Deviazione standard solo Te: " << CalcolaDev(contributoTe) << endl;
	
	dev.push_back(CalcolaDev(contributoM));
	cout << "Deviazione standard solo M: " << CalcolaDev(contributoM) << endl;

	
	cout << "correlazione tra Ma e M: " << CalcolaCorrelazione(contributoMa, contributoM) << endl;
	cout << "correlazione tra Ta e Te:" << CalcolaCorrelazione(contributoTa, contributoTe) << endl;
	cout << "correlazione tra Ta e Tc: " << CalcolaCorrelazione(contributoTa, contributoTc) << endl;
	cout << "correlazione tra Te e Tc:" << CalcolaCorrelazione(contributoTc, contributoTe) << endl; 

	return dev;
}*/
#include <cmath>
#include "iostream"
#include "RandomGen.h"
#include "Funzioni.h"
#include <iomanip>

using namespace std;

double RandomGen::Rand(){
	m_seed = (m_a*m_seed + m_c)%m_m;
	return m_seed/double(m_m);
}

double RandomGen::Unif(double xmin, double xmax) {
	//genero un numero tra (0,1)
	double di = Rand();
	//ricavo un numero all'interno dell'intervallo richiesto
	double number = xmin + (xmax - xmin)*di;
	//cout << number << endl;
	return number;
}

double RandomGen::Exp(double mean) {
	
	double y = Rand();
	double x = -(1/mean)*log(1-y);
	cout << x << endl;
	return x;
}

double RandomGen::Gauss(double mean, double sigma) {
	double s = Rand();
	double t = Rand();
	double x = sqrt(-2*log(s))*cos(2*M_PI*t);
	//faccio sì che il punto trovato rispetti i parametri inseriti per la gaussiana
	double gauss = mean + x*sigma;
	cout << gauss << endl;
	return gauss;
}

//implementazione metodo per distribuzione Gaussiana con AcceptReject
double RandomGen::GaussAR(double mean, double sigma) {
	//costruisco una funzione Gaussiana con i parametri inseriti
	Gaussiana g(mean, sigma);

	//definisco due variabili double come coordinate del punto che devo estrarre
	double x = 0;
	double y = 0;
	double M = 1000;

	//creo un ciclo for infinito che termina quando estraggo casualmente un punto che sta sotto il grafico della funzione
	for(;;) {
		x = Unif(mean-M, mean+M); //estraggo un numero in un intervallo intorno al valore medio
		y = Unif(0,M/2); //estraggo un numero in un intervallo di y
		if(y <g.Eval(x)) //controllo se il punto sta sotto il grafico della Gaussiana
			break;
	}
	cout << x << "," << y << endl;
	return x; //mi faccio restituire l'ascissa del punto estratto
}


double RandomGen::AcceptReject(FunzioneBase *f) {
	//immagino che la funzione sia stata costruita, e quindi i parametri inizializzati nel main
	double x = 0;
	double y = 0;
	double M = 1000;
	for(;;) {
		x = Unif(-M,M); //nel caso possono essere cambiati i parametri dell'intervallo
		y = Unif(0,M);
		if(y <f->Eval(x)) //controllo se il punto sta sotto il grafico della funzione
			break;
	}
	cout << x << "," << y << endl;
	return x;
}
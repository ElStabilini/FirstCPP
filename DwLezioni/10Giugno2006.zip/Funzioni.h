#ifndef __funzioni_h__
#define __funzioni_h__

#include <iostream>
#include <cmath>
#include <vector>

//SE da problemi in fase di copmilazione commenta le funzioni print

/*
	DICHIARAZIONE FUNZIONE BASE - FUNZIONE MADRE ASTRATTA
*/

using namespace std;

class FunzioneBase{

public:

  	virtual double Eval(double x) const = 0;
	virtual void Print() const = 0;
	//virtual double operator () (double x) const = 0;
};



/* =========================================================================
	DICHIARAZIONE FUNZIONE SOMMA
==========================================================================*/
class FunzioneSomma : public FunzioneBase {

public:
	//costruttore
	FunzioneSomma(FunzioneBase * f1, FunzioneBase * f2) {m_f1 = f1; m_f2 = f2;};
	virtual double Eval(double x) const {return m_f1->Eval(x) + m_f2->Eval(x);};

private:
	FunzioneBase * m_f1;
	FunzioneBase * m_f2;

};

/* =========================================================================
	DICHIARAZIONE FUNZIONE PRODOTO
==========================================================================*/

class FunzioneProdotto : public FunzioneBase {

public:
	//costruttore
	FunzioneProdotto(FunzioneBase * f1, FunzioneBase * f2) {m_f1 = f1; m_f2 = f2;};
	virtual	double Eval(double x) const {return m_f1->Eval(x)*m_f2->Eval(x);};

private:
	FunzioneBase * m_f1;
	FunzioneBase * m_f2;
};

/* =========================================================================
	DICHIARAZIONE FUNZIONE DIFFERENZA
==========================================================================*/

class FunzioneDifferenza : public FunzioneBase {

public:
	//costruttore
	FunzioneDifferenza(FunzioneBase * f1, FunzioneBase * f2) {m_f1 = f1; m_f2 = f2;};
	virtual	double Eval(double x) const {return m_f1->Eval(x)-m_f2->Eval(x);};

private:
	FunzioneBase * m_f1;
	FunzioneBase * m_f2;
};

class Errore : public FunzioneBase {

public:
	Errore(double p0, double p1, double p2) {
		m_p0 = p0;
		m_p1 = p1;
		m_p2 = p2;
	}
	virtual double Eval(double x) const {
		return p0 + p1*pow(x, p2);
	}

private:
	double m_p0, m_p1, m_p2;
};


#endif
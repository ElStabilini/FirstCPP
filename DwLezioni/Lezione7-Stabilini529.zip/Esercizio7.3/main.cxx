#include <iostream>
#include <cmath>
#include <string>
#include <vector>
#include <iomanip>
#include "Funzioni.h"
#include "AlgoZeri.h"
#define _USE_MATH_DEFINES

using namespace std;

int main(int argc , char** argv) {
	if ( argc != 4 ) {
    cerr << "Uso del programma : " << argv[0] << " <i> <n_inter> <precisione>" << endl;
    return -1 ;
  }

	//chiedo di inserire ul numero di iterazioni e la precisione
	int start = atoi(argv[1]); //numero del primo intervallo su cui voglio cercare la soluzione
	int n_inter = atoi(argv[2]);
	double prec = atof(argv[3]);
	
	double n = start + n_inter;
	cout << "n =" << n << endl;
	double v[n_inter];

	FunzioneBase * x = new Retta(1, 0);
	FunzioneBase * cosx = new Coseno(1, 1, 0, 0);
	FunzioneBase * sinx = new Coseno(1, 1, - M_PI/2, 0);
	FunzioneBase * xcosx = new FunzioneProdotto(x, cosx);
	FunzioneBase * f = new FunzioneDifferenza(sinx, xcosx);

	
	for (int i=start; i<n; i++) {
		cout << "i*M_PI = " << i*M_PI << endl;
		cout << "i*M_PI = " << i*M_PI + M_PI/2 << endl;
		Solutore * mybisezione = new Bisezione(i*M_PI, i*M_PI + M_PI/2, prec);
		v[i-start+1] = mybisezione->CercaZeri(i*M_PI, i*M_PI + M_PI/2, f);
		delete[] mybisezione;
	}

	cout << setw(10) <<"intervallo " << setw(10) << "zero dell'intervallo" << endl; 
	for (int i=start; i<n; i++) {
		 cout << setw(10) << i << setw(10) << v[i] << endl;
	}

	delete[] cosx;
	delete[] sinx;
	delete[] x;
	delete[] xcosx;
	delete[] f;
	return 0;
};  

//sinx -xcosx =0;
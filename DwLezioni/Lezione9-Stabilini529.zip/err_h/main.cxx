#include <iostream>

#include "TApplication.h"
#include "TCanvas.h" 
#include "TGraph.h"
#include "TAxis.h"

#include "EquazioniDifferenziali.h"
#include "Funzioni.h"
//#include "VectorOperations.h"

using namespace std;

int main(int argc, char** argv){
  
  TApplication myApp("myApp",0,0);

  Eulero myEuler;
	Coseno sinx {1, 1, - M_PI/2, 0};

  OscillatoreArmonico * osc = new OscillatoreArmonico (1.0);

  double tmax = 70.0;
  vector<double> x {0.0, 1.0};
  double t = 0.0;

	//plot del grafico dell'errore
	TGraph *errore = new TGraph();

	for (int i =0; i<10; i++) {
		double h = 0.1*pow(0.5, i);
		//riazzero le condizioni all'inizio di ogni ciclo
		vector<double> x1 {0, 1};
		double t = 0;
		int nstep = int(tmax/h + 0.5);

		for (int step=0; step < nstep; step++) {
			x1 = myEuler.Passo(t, x1, h, osc);
			t = t+h;
		}

		double eps = fabs(x1[0] - sinx.Eval(tmax));
		errore->SetPoint(i, h, eps);
	}

	TCanvas myCanvas("errore", "Errore in funzione del passo", 600, 600);
	errore->GetXaxis()->SetTitle("Passo [h]");
	errore->GetYaxis()->SetTitle("Delta posizione x [m]");
	errore->Draw("ALP");

	delete[] osc;

  myApp.Run();

  return 0;
}

#ifndef __funzioni_stat_h__
#define __funzioni_stat_h__

#include <iostream>
#include <fstream> 
#include <cstdlib>
#include <cmath>
#include "Vettore.h"
#include "funzioni_vec.h"

using namespace std;

double CalcolaMedia( const Vettore & ) ;
double CalcolaVarianza( const Vettore & ) ;
double CalcolaMediana (Vettore &);

#endif // __funzioni_stat_h__
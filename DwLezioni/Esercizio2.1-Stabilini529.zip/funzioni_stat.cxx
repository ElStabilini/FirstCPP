#include "funzioni_stat.h"
#include "funzioni_vec.h"
#include "Vettore.h"

using namespace std;

double CalcolaMedia( const Vettore& V) {
	unsigned int N=V.GetN();
	double sum = 0;
	for (int i=0; i<N; i++)
		sum = sum + V.GetComponent(i);
	return sum/N;
}

double CalcolaVarianza( const Vettore& V ) {
 double scarto = 0;
 unsigned int N = V.GetN();
  for (int i=0; i<N; i++)
    scarto = scarto + pow(V.GetComponent(i) - CalcolaMedia(V), 2);
  return scarto/N;
}
                                 
double CalcolaMediana (Vettore & V) {
  double mediana = 0;
	unsigned int size = V.GetN();
	double n=V.GetN()/2;
  int x = (int)n;
  Vettore_selection_sort(V); //riordino il vettore copiato

    if (size%2 == 0) {  //se hai un numero pari di dati fai la media tra i due valori centrali
    mediana = (V.GetComponent(x)+V.GetComponent(x-1))/2;
      } else {       //se il numero di dati è dispari restituisce il valore centrale
    mediana = V.GetComponent(x);
    }
  return mediana;
}
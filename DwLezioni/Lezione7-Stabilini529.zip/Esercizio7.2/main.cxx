#include <iostream>
#include <cmath>
#include <string>
#include "Funzioni.h"
#include "AlgoZeri.h"

using namespace std;

int main(int argc , char** argv) {
	if ( argc != 7 ) {
    cerr << "Uso del programma : " << argv[0] << " <a> <b> <c> <estremo sx> <estremo dx> <precisione>" << endl;
    return -1 ;
  }
 
	double a = atof(argv[1]);
	double b = atof(argv[2]);
	double c = atof(argv[3]);
	double xmin = atof(argv[4]);
	double xmax = atof(argv[5]);
	double prec = atof(argv[6]);

	FunzioneBase * myparabola = new Parabola(a, b, c);
	Solutore * mybisezione = new Bisezione(xmin, xmax, prec);

	myparabola->Print();
	mybisezione->CercaZeri(xmin, xmax, myparabola);

	delete[] myparabola;
	return 0;
};  
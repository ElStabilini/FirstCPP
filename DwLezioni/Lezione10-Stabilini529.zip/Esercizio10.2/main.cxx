#include "TApplication.h"
#include "TCanvas.h"
#include "TH1F.h"
#include "TAxis.h"
#include "TGraph.h"
#include "IntegrazioneMC.h"
#include "Funzioni.h"
#include "RandomGen.h"
#include "statistica.h"

#include <fstream>
#include <cstdlib>
#include <iostream>

#define _USE_MATH_DEFINES

using namespace std;

int main() {

	TApplication app("app",0,0);

	fstream fileout1, fileout2;
  Coseno* sinx = new Coseno(1, 1, - M_PI/2, 0);
	IntegraleMC myintegral(1);
	double pi = M_PI;
	double xh1 = 0, xh2 = 0, xh3 = 0, xh4 = 0, xh5 =0;
	double xm1 = 0, xm2 = 0, xm3 = 0, xm4 = 0, xm5 =0;

	vector<double> HM1, HM2, HM3, HM4, HM5;
	vector<double> M1, M2, M3, M4, M5;

	fileout1.open("integraliHitMiss.dat", ios::out);
	if (!fileout1.good())
		cerr << "errore apertura file integrali.dat" << endl;

	fileout2.open("integraliMedia.dat", ios::out);
	if (!fileout2.good())
		cerr << "errore apertura file integrali.dat" << endl;

	TH1F Ih1("Integrale 100 (HM)","Integrale 100 (HM)", 100, 1.7, 2.3);
	TH1F Ih2("Integrale 500 (HM)","Integrale 500 (HM)", 100, 1.7, 2.3);
	TH1F Ih3("Integrale 1000 (HM)","Integrale 1000 (HM)", 100, 1.7, 2.3);
	TH1F Ih4("Integrale 5000 (HM)","Integrale 5000 (HM)", 100, 1.7, 2.3);
	TH1F Ih5("Integrale 10000 (HM)","Integrale 10000 (HM)", 100, 1.7, 2.3);
	TH1F Im1("Integrale 100 (M)","Integrale 100 (M)", 100, 1.7, 2.3);
	TH1F Im2("Integrale 500 (M)","Integrale 500 (M)", 100, 1.7, 2.3);
	TH1F Im3("Integrale 1000 (M)","Integrale 1000 (M)", 100, 1.7, 2.3);
	TH1F Im4("Integrale 5000 (M)","Integrale 5000 (M)", 100, 1.7, 2.3);
	TH1F Im5("Integrale 10000 (M)","Integrale 10000 (M)", 100, 1.7, 2.3);

//calcolo 10000 volte il valore dell'integrale
	for(int i=0; i<10000; i++) {
		xh1 = myintegral.HitMiss(sinx, 0, pi, 100, 1);
		xh2 = myintegral.HitMiss(sinx, 0, pi, 500, 1);
		xh3 = myintegral.HitMiss(sinx, 0, pi, 1000, 1);
		xh4 = myintegral.HitMiss(sinx, 0, pi, 5000, 1);
		xh5 = myintegral.HitMiss(sinx, 0, pi, 10000, 1);
		xm1 = myintegral.Media(sinx, 0, pi, 100);
		xm2 = myintegral.Media(sinx, 0, pi, 500);
		xm3 = myintegral.Media(sinx, 0, pi, 1000);
		xm4 = myintegral.Media(sinx, 0, pi, 5000);
		xm5 = myintegral.Media(sinx, 0, pi, 10000);

		HM1.push_back(xh1);
		HM2.push_back(xh2);
		HM3.push_back(xh3);
		HM4.push_back(xh4);
		HM5.push_back(xh5);
		M1.push_back(xm1);
		M2.push_back(xm2);
		M3.push_back(xm3);
		M4.push_back(xm4);
		M5.push_back(xm5);

		Ih1.Fill(xh1);
		Ih2.Fill(xh2);
		Ih3.Fill(xh3);
		Ih4.Fill(xh4);
		Ih5.Fill(xh5);
		Im1.Fill(xm1);
		Im2.Fill(xm2);
		Im3.Fill(xm3);
		Im4.Fill(xm4);
		Im5.Fill(xm5);
	}

	for (int i=0; i<100; i++)
		fileout1 << HM1[i] << setw(10) << HM2[i] << setw(10) << HM3[i] << setw(10) << HM4[i] << setw(10) << HM5[i] << setw(10) <<endl;

	for (int i=0; i<10000; i++)
		fileout2 << M1[i] << setw(10) << M2[i] << setw(10) << M3[i] << setw(10) << M4[i] << setw(10) << M5[i] << setw(10) <<endl;
	
	TCanvas CHitMiss("Metodo Hit or Miss");
	CHitMiss.Divide(5,1);
	
	CHitMiss.cd(1);
	Ih1.GetXaxis()->SetTitle("x [AU]");
  Ih1.GetYaxis()->SetTitle("N");
  Ih1.Draw();

  CHitMiss.cd(2);
  Ih2.GetXaxis()->SetTitle("x [AU]");
  Ih2.GetYaxis()->SetTitle("N");
  Ih2.Draw();

	CHitMiss.cd(3);
  Ih3.GetXaxis()->SetTitle("x [AU]");
  Ih3.GetYaxis()->SetTitle("N");
  Ih3.Draw();

 	CHitMiss.cd(4);
  Ih4.GetXaxis()->SetTitle("x [AU]");
  Ih4.GetYaxis()->SetTitle("N");
  Ih4.Draw();

  CHitMiss.cd(5);
  Ih5.GetXaxis()->SetTitle("x [AU]");
  Ih5.GetYaxis()->SetTitle("N");
  Ih5.Draw();


	TCanvas CMedia("Metodo Media");
	CMedia.Divide(5,1);
	
  CMedia.cd(1);
  Im1.GetXaxis()->SetTitle("x [AU]");
  Im1.GetYaxis()->SetTitle("N");
  Im1.Draw();

  CMedia.cd(2);
  Im2.GetXaxis()->SetTitle("x [AU]");
  Im2.GetYaxis()->SetTitle("N");
  Im2.Draw();

  CMedia.cd(3);
  Im3.GetXaxis()->SetTitle("x [AU]");
  Im3.GetYaxis()->SetTitle("N");
  Im3.Draw();

  CMedia.cd(4);
  Im4.GetXaxis()->SetTitle("x [AU]");
  Im4.GetYaxis()->SetTitle("N");
  Im4.Draw();

  CMedia.cd(5);
  Im5.GetXaxis()->SetTitle("x [AU]");
  Im5.GetYaxis()->SetTitle("N");
  Im5.Draw();

	//calcolo l'errore come deviazione standard
	vector<double> Dev;
	Dev.push_back(CalcolaDev(HM1));
	Dev.push_back(CalcolaDev(HM2));
	Dev.push_back(CalcolaDev(HM3));
	Dev.push_back(CalcolaDev(HM4));
	Dev.push_back(CalcolaDev(HM5));
	Dev.push_back(CalcolaDev(M1));
	Dev.push_back(CalcolaDev(M2));
	Dev.push_back(CalcolaDev(M3));
	Dev.push_back(CalcolaDev(M4));
	Dev.push_back(CalcolaDev(M5));

	/*for (int i=0; i<Dev.size(); i++)
		cout << Dev[i] << endl;*/


	//plot errore in funzione di N
	double n[5] = {100, 500, 1000, 5000, 10000};
	TGraph * erroreMedia = new TGraph();
	TGraph * erroreHitMiss = new TGraph(); 

	for (int i=0; i<Dev.size()/2; i++) {
		erroreHitMiss->SetPoint(i, n[i], Dev[i]);
		erroreMedia->SetPoint(i, n[i], Dev[i+5]);
	}

	TCanvas * c = new TCanvas("andamento errore", "Andamento errore e(N)");
	c->Divide(2,1);
	c->cd(1);
	erroreHitMiss->SetTitle("metodo Hit Miss");
	erroreHitMiss->GetXaxis()->SetTitle("N");
	erroreHitMiss->GetYaxis()->SetTitle("Errore [UA]");	
	erroreHitMiss->Draw("ACP*");
	c->cd(2);
	erroreMedia->SetTitle("metodo della Media");
	erroreMedia->GetXaxis()->SetTitle("N");
	erroreMedia->GetYaxis()->SetTitle("Errore [UA]");	
	erroreMedia->Draw("ACP*");


	vector<double> K;
	vector<double> N;
	for (int i=0; i<Dev.size(); i++) {
		if (i<5)
			K.push_back(Dev[i]*sqrt(n[i]));
		else
			K.push_back(Dev[i]*sqrt(n[i-5]));

		N.push_back((K[i]*K[i])/(0.001*0.001));
	}

	cout << "numero di punti necessari per avere una precisione assoluta di 0.001: " << endl;
	for (int i=0; i<N.size(); i++)
		cout << (N[i]) << endl;

	

	fileout1.close();
	fileout2.close();

	app.Run();


	return 0;
}
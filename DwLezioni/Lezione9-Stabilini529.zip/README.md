# Esercitazione 9

Gli esercizi proposti sul sito web del laboratorio verranno affrontati in due esercitazioni:

## Prima parte
- 9.0: testare l'algebra dei vettori;
- 9.1: risolvere equazione differenziale col metodo di Eulero;

## Seconda parte
- 9.2: risolvere equazione differenziale col metodo di Runge-Kutta (**da consegnare**);
- 9.3: calcolo del periodo di oscillazione di un pendolo (**da consegnare**);
- 9.4: studio della condizione di risonanza di un oscillatore forzato (**da consegnare**);
- 9.5: moto in campo gravitazionale;
- 9.6: moto di particella in campo elettromagnetico.

Per questa esercitazione avrete bisogno di ROOT. Per scaricarlo nella vostra _main directory_ eseguite nella shell della finestra Repl di destra gli usuali comandi:
  * wget https://root.cern/download/root_v6.22.02.Linux-ubuntu18-x86_64-gcc7.5.tar.gz
  * tar -zxvf root_v6.22.02.Linux-ubuntu18-x86_64-gcc7.5.tar.gz
  * source setup.sh

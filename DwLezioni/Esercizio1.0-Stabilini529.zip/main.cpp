#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>

using namespace std;

int main ( int argc, char** argv ) {

  if ( argc < 3 ) {
    cout << "Uso del programma : " << argv[0] << " <n_data> <filename> " << endl;
    return -1 ;
  }

  fstream f, g;
  int ndata = atoi(argv[1]);
  double* data = new double[ndata];
  char * filename = argv[2];
  double Media = 0;
  double var = 0;

  f.open("data.dat", ios::in);
	if (!f.good())
		cerr << "errore apertura file data.dat" << endl;

  // [ ... 1) leggi dati da file e caricali nel c-array data ... ] 
  for (int i = 0; i < ndata; i++) {
      f >> data[i];
      if (f.eof()) {
        cout << "fine dati da leggere" << endl;
        break;
      }
  }

  for ( int k = 0 ; k < ndata ; k++ ) cout << data[k] << endl;
  cout << endl; 
   // dopo averli caricati visualizzo
   
  // [ ... 2) calcolo la media e la varianza degli elementi caricati ... ]

  double sum =0;
   for (int i=0; i<ndata; i++)
		  sum = sum + data[i];

  cout << "somma " << sum << endl; 
  double media = sum/ndata;

  double scarto = 0;
  for (int i=0; i<ndata; i++)
      scarto = scarto + pow(data[i] - media, 2);
  
  cout << "scarto " << scarto << endl;
  var = scarto/ndata;

  cout << "Media =  " << media << "   Varianza = " << var << endl;
  cout << endl;

  //  calcola la mediana : prima creo una copia del vettore di partenza

  double * vcopy = new double[ndata];
  for ( int k = 0 ; k < ndata ; k ++ ) vcopy[k] = data[k];

  // [ ... 3) poi riordino gli elementi del vettore copia dal minore al maggiore ... ]
  for (int i=0; i < ndata; i++)
		for (int j=0; j < ndata; j++)
			if(vcopy[i] > vcopy[j]) {
				double tmp = vcopy[i];
				vcopy[i] = vcopy[j];
				vcopy[j] = tmp;
			}

  cout << "stampo i dati in ordine decrescente" << endl;
  for ( int k = 0 ; k < ndata ; k++ ) cout << vcopy[k] << endl; // dopo averli riordinati visualizzo
  cout << endl;

  // [ ... 4) poi prendo il valore centrale ( ndata dispari ) o la media tra i due centrali
  double mediana = 0;
  double n=ndata/2;
  int x = (int)n;

  if (ndata%2 == 0) {
    mediana = (vcopy[x+1]+vcopy[x-1])/2;
  } else {
    mediana = vcopy[x];
  }
  
  cout << "Mediana = " << mediana << endl; // stampa la mediana calcolata
  cout << endl;                                                                                 
  // visualizzo l'array originale [......]                                                         
  for ( int k = 0 ; k < ndata ; k++ ) cout << data[k] << endl; 
                                                               
  // [ ... 5) scrivo i dati riordinati su un file ... ]
  g.open("risultati.dat", ios::out);
	if (!g.good())
		cerr << "errore apertura file risultati.dat" << endl; 

  for ( int k = 0 ; k < ndata ; k++ ) 
    g << data[k] << endl; 
    g << endl;
  
  g << "Media =  " << media << "   Varianza = " << var << endl;
  g << endl;
  
  g << "stampo i dati in ordine decrescente" << endl;
  for ( int k = 0 ; k < ndata ; k++ ) 
    g << vcopy[k] << endl;
  g << endl;
  
  g << "Mediana = " << mediana << endl;
  for ( int k = 0 ; k < ndata ; k++ ) 
    g << data[k] << endl;
  g << endl;  

  delete [] vcopy;
  delete [] data;
  
  return 0;
}
#include "Esperimento.h"
#include "Funzioni.h"
#include "AlgoZeri.h"

#include <cmath>
#include <vector>
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <iomanip>

#define _USE_MATH_DEFINES

#include "TApplication.h"
#include "TCanvas.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TF1.h"
#include "TAxis.h"
#include "statistica.h"

using namespace std;

int main() {

	TApplication app("app", 0, 0);
	Esperimento myExp;
	vector <double> Rin1, Rin3, Rin5, Rin7, Rin9;

	cout << setw(15) << "Sigma Resistenze" << setw(15) << "Resistenza internza" << setw(15) << "incertezza" << endl;

	Rin1 = myExp.EsperimentoCompleto(5000);
	myExp.SetSigma(3.);
	Rin3 = myExp.EsperimentoCompleto(5000);
	myExp.SetSigma(5);
	Rin5 = myExp.EsperimentoCompleto(5000);
	myExp.SetSigma(7);
	Rin7 = myExp.EsperimentoCompleto(5000);
	myExp.SetSigma(9);
	Rin9 = myExp.EsperimentoCompleto(5000);

//PUNTO 2

	TH1F * ResistenzaInt1 = new TH1F("Resistenza interna (sigma = 1)", "Resistenza interna (sigma = 1)", 100, 30, 90);
	ResistenzaInt1->StatOverflows( kTRUE );
	TH1F * ResistenzaInt3 = new TH1F("Resistenza interna (sigma = 3)", "Resistenza interna (sigma = 3)", 100, 30, 90);
	ResistenzaInt3->StatOverflows( kTRUE );
	TH1F * ResistenzaInt5 = new TH1F("Resistenza interna (sigma = 5)", "Resistenza interna (sigma = 5)", 100, 30, 90);
	ResistenzaInt5->StatOverflows( kTRUE );
	TH1F * ResistenzaInt7 = new TH1F("Resistenza interna (sigma = 7)", "Resistenza interna (sigma = 7)", 100, 30, 90);
	ResistenzaInt7->StatOverflows( kTRUE );
	TH1F * ResistenzaInt9 = new TH1F("Resistenza interna (sigma = 9)", "Resistenza interna (sigma = 9)", 100, 30, 90);
	ResistenzaInt9->StatOverflows( kTRUE );

	for(int i=0; i<5000; i++) {
		ResistenzaInt1->Fill(Rin1[i]);
		ResistenzaInt3->Fill(Rin3[i]);
		ResistenzaInt5->Fill(Rin5[i]);
		ResistenzaInt7->Fill(Rin7[i]);
		ResistenzaInt9->Fill(Rin9[i]);
	}

	TCanvas *c1 = new TCanvas("Resistenza Interna", "Resistenza Interna");
	c1 -> Divide(5,1);
	c1->cd(1);
	ResistenzaInt1->SetTitle("Sigma = 1");
	ResistenzaInt1->GetXaxis()->SetTitle("R [Ohm]");
	ResistenzaInt1->GetYaxis()->SetTitle("frequenza");
	ResistenzaInt1->Draw();
	c1->cd(2);
	ResistenzaInt3->SetTitle("Sigma = 3");
	ResistenzaInt3->GetXaxis()->SetTitle("R [Ohm]");
	ResistenzaInt3->GetYaxis()->SetTitle("frequenza");
	ResistenzaInt3->Draw();
	c1->cd(3);
	ResistenzaInt5->SetTitle("Sigma = 5");
	ResistenzaInt5->GetXaxis()->SetTitle("R [Ohm]");
	ResistenzaInt5->GetYaxis()->SetTitle("frequenza");
	ResistenzaInt5->Draw();
	c1->cd(4);
	ResistenzaInt7->SetTitle("Sigma = 7");
	ResistenzaInt7->GetXaxis()->SetTitle("R [Ohm]");
	ResistenzaInt7->GetYaxis()->SetTitle("frequenza");
	ResistenzaInt7->Draw();
	c1->cd(5);
	ResistenzaInt9->SetTitle("Sigma = 9");
	ResistenzaInt9->GetXaxis()->SetTitle("R [Ohm]");
	ResistenzaInt9->GetYaxis()->SetTitle("frequenza");
	ResistenzaInt9->Draw();

//calcolo dei coefficienti
	cout << "espeirmento per il calcolo dei coefficienti" << endl;
	vector<double> s;
	double sigma = 1;
	myExp.SetSigma(sigma);
	s.push_back(CalcolaDev(myExp.EsperimentoCompleto(5000)));
	myExp.SetSigma(2*sigma);
	s.push_back(CalcolaDev(myExp.EsperimentoCompleto(5000)));
	myExp.SetSigma(4*sigma);
	s.push_back(CalcolaDev(myExp.EsperimentoCompleto(5000)));

	double p2 = log2(s[0]/s[1]);
	double p0 = (s[2]*s[0]/s[1] - s[2])/(s[0]/s[1] - 1);
	double p1 = (s[1]- p0)*s[0]/s[1];

	cout << "parametri andamento errore" << endl;
	cout << "p0: " << p0 << endl;
	cout << "p1: " << p1 << endl;
	cout << "p2: " << p2 << endl;




	app.Run();
	return 0;
}
#include <iostream>
#include <cmath>
#include <string>
#include "Funzioni.h"

using namespace std;

int main(int argc , char** argv) {

	if ( argc != 5 ) {
    cerr << "Uso del programma : " << argv[0] << " <a> <b> <c> <x> " << endl;
    return -1 ;
  }

	double a = atof(argv[1]);
	double b = atof(argv[2]);
	double c = atof(argv[3]);
	double x = atof(argv[4]);

	Parabola f(a, b, c);
	FunzioneBase * myparabola = new Parabola(a, b, c);

	cout << "valore della parabola in " << x << " = " << myparabola->Eval(x) << endl;
	myparabola->Print();
	cout << f(x) << endl;	

	delete[] myparabola;
	return 0;
}
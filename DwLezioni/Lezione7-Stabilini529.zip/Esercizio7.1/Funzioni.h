/*
The representation of a function is coded here. Base class
and derived classes can be found 
*/

#ifndef __funzioni_h__
#define __funzioni_h__

#include <iostream>
#include <cmath>

using namespace std;

class FunzioneBase{

public:

  virtual double Eval(double x) const = 0;
	virtual void Print() const = 0;
	virtual double operator () (double x) const = 0;
};

class Parabola: public FunzioneBase{

public:
	
	//costruttori
  Parabola();
  Parabola(double a, double b, double c);

	//costruttore di copia
	Parabola(const Parabola& p);

	//distruttore
  ~Parabola() {;};

  virtual double Eval(double x) const {return m_a*x*x + m_b*x + m_c;};
  void SetA(double a) {m_a = a;};
  void SetB(double b) {m_b = b;};
  void SetC(double c) {m_c = c;};
  double GetA() const {return m_a;};
  double GetB() const {return m_b;};
  double GetC() const {return m_c;};

	double GetVertice() const {return -GetB()/(2*GetA());};
	virtual void Print () const;

	virtual double operator() (double x) const {return m_a*x*x + m_b*x + m_c;};

private:

  double m_a, m_b, m_c;

};


#endif
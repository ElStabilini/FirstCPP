DIR=`pwd`
source $DIR/root/bin/thisroot.sh
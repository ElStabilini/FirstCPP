**Esercitazione 8**

Come al solito se vorrete provare a fare un grafico dell'errore in funzione del passo h utilizzato avrete bisogno di ROOT. 
Per scaricarlo nella vostra _main directory_ eseguite gli usuali comandi:
  * wget https://root.cern/download/root_v6.22.02.Linux-ubuntu18-x86_64-gcc7.5.tar.gz
  * tar -zxvf root_v6.22.02.Linux-ubuntu18-x86_64-gcc7.5.tar.gz
  * source setup.sh

Una volta scompattato il file root_v6.22.02.Linux-ubuntu18-x86_64-gcc7.5.tar.gz puo' essere rimosso
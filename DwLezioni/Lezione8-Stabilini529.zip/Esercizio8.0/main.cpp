#include <iostream>
#include <cmath>
#include <iomanip>
#define _USE_MATH_DEFINES


#include "Funzioni.h"
#include "Integral.h"

#include "TH1F.h"
#include "TApplication.h"
#include "TCanvas.h"
#include "TGraph.h"

using namespace std;

int main(int argc, const char ** argv){

	TApplication app("app",0,0);
  
  if (argc != 2) {
    cout << "Usage: ./main nstep" << endl;
    return -1;
  }

  double a = 0.;
  double b = M_PI;

  int nstep = atoi(argv[1]);

  Coseno* mysin = new Coseno(1, 1, - M_PI/2, 0);
  Integral* integrator = new Integral(a,b,mysin);

	TGraph *g = new TGraph();
	
	cout << setw(10) <<"nstep" << setw(10) << "delta" << endl;

	int i=1;

	while(i < 1000) {
		double delta = fabs(2 - integrator->Midpoint(i));
		double h = integrator->GetH();

		cout << setw(10) << i << "  "<< setw(10) << delta << endl;

		g->SetPoint(i-1, h, delta);

		i=2*i;
	}

	cout << setprecision(12) << integrator->Midpoint(nstep) <<endl;

	TCanvas * Plot = new TCanvas("Plot", "differenza", 500, 500); 
	Plot->cd();
	g->Draw("A*"); 
	g->SetTitle("differenza integrale - approssimazione");
	g->GetXaxis()->SetTitle("GetH");
	g->GetYaxis()->SetTitle("delta");

  app.Run();
  return 0;
}

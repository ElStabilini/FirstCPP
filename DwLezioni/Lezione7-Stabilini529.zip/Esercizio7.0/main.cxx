
#include <iostream>
#include <cmath>
#include <string>
#include "particella.h"

using namespace std;

int main() {
	Particella *a = new Particella(1.,2.);
	Elettrone *e = new Elettrone();
	Particella *b = new Elettrone(); //puntatore a Partiecella punta a un Elettrone

	a->Print();
	e->Print();
	b->Print();

	delete a;
	delete b;
	delete e;

	return 0;
}
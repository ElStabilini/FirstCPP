#include "TApplication.h"
#include "TCanvas.h"
#include "TH1F.h"
#include "TAxis.h"

#include <iostream>

#include "RandomGen.h"

using namespace std;

int main() {
  
   TApplication app("app",0,0);

   RandomGen mygen(1);

   int nmax = 1000;
	 
	 //creo grafici per le diverse distribuzioni di numeri casuali
   TH1F unif("Uniforme","Uniforme",100,4,11);
	 TH1F exp("Esponenziale", "Esponenziale", 100, 0, 3);
	 //TH1F gauss("Gauss", "Gauss", 100, 0, 100 );
	 TH1F gaussAR("Gauss accept-reject", "Gauss accept-reject", 100, 0, 40);

	//distribuzione uniforme su (5,10)
	for (int k=0; k<nmax; k++)
    unif.Fill(mygen.Unif(5,10));

	//distribuzione esponenziale centrata in 5
	for (int i=0; i<nmax; i++)
	 	exp.Fill(mygen.Exp(5));

	//distribuzione gaussiana con media 20 e sigma 2
	/*for (int i=0; i<nmax; i++)
		gauss.Fill(mygen.Gauss(20,2));*/

	//distribuzione gaussiana costruita con metodo accept reject
	for (int i=0; i<nmax; i++)
		gaussAR.Fill(mygen.GaussAR(20, 2));

	//creo i canvas per disegnare i grafici
	 TCanvas c1("Esponenziale","Esponenziale");
   c1.cd();
   exp.GetXaxis()->SetTitle("x [AU]");
   exp.GetYaxis()->SetTitle("N");
   exp.Draw();

	 TCanvas c2("Uniforme","Uniforme");
   c2.cd();
   unif.GetXaxis()->SetTitle("x [AU]");
   unif.GetYaxis()->SetTitle("N");
   unif.Draw();


   TCanvas c3("Gauss accept-reject","Gauss accept-reject");
   c3.cd();
   gaussAR.GetXaxis()->SetTitle("x [AU]");
   gaussAR.GetYaxis()->SetTitle("N");
   gaussAR.Draw();

	/*TCanvas c4("Gauss","Gauss");
   c4.cd();
   gauss.GetXaxis()->SetTitle("x [AU]");
   gauss.GetYaxis()->SetTitle("N");
   gauss.Draw();*/

   app.Run();
   return 0;
}


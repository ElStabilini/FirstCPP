#include "Particella.h"
#include "Posizione.h"
#include "CampoVettoriale.h"
#include <cmath>
#include <iostream>

using namespace std;

int main(int argc , char** argv) {

	

	return 0;
}
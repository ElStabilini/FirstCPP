#ifndef __funzioni_h__
#define __funzioni_h__

#include <iostream>
#include <cmath>
#include <vector>

/*
	DICHIARAZIONE FUNZIONE BASE - FUNZIONE MADRE ASTRATTA
*/

using namespace std;

class FunzioneBase{

public:

  virtual double Eval(double x) const = 0;
	virtual void Print() const = 0;
	//virtual double operator () (double x) const = 0;
};

/*
	DICHIARAZIONE PARABOLA
*/
class Parabola: public FunzioneBase{

public:
	
	//costruttori
  Parabola();
  Parabola(double a, double b, double c);

	//costruttore di copia
	Parabola(const Parabola& p);

	//distruttore
  ~Parabola() {;};

  virtual double Eval(double x) const {return m_a*x*x + m_b*x + m_c;};
  void SetA(double a) {m_a = a;};
  void SetB(double b) {m_b = b;};
  void SetC(double c) {m_c = c;};
  double GetA() const {return m_a;};
  double GetB() const {return m_b;};
  double GetC() const {return m_c;};

	double GetVertice() const {return -GetB()/(2*GetA());};
	virtual void Print () const;

	virtual double operator() (double x) const {return m_a*x*x + m_b*x + m_c;};

private:

  double m_a, m_b, m_c;

};

/*
	DICHIARAZIONE FUNZIONE SENO
*/

class Coseno : public FunzioneBase {

public:
	Coseno() {m_a = 0; m_b = 1; m_c = 0; m_d = 0;};
	Coseno(double a, double b, double c, double d) { m_a = a;	m_b = b; m_c = c; m_d = d;};

  ~Coseno() {;};

	void SetA(double a) {m_a = a;};
  void SetB(double b) {m_b = b;};
  void SetC(double c) {m_c = c;};
	void SetD(double d) {m_d = d;};
  double GetA() const {return m_a;};
  double GetB() const {return m_b;};
  double GetC() const {return m_c;};
	double GetD() const {return m_d;};

	virtual double Eval(double x) const {return m_a*cos(m_b*x + m_c) + m_d;};

	virtual void Print() const;

private:
	double m_a, m_b, m_c, m_d;

};

/*
	DICHIARAZIONE FUNZIONE RETTA
*/

class Retta : public FunzioneBase {

public:

	Retta() {m_a = 0; m_b = 0;};
	Retta(double a, double b) {m_a = a; m_b = b;};

	~Retta() {;};

  double GetA() const {return m_a;};
  double GetB() const {return m_b;};
	void SetA(double a) {m_a = a;};
  void SetB(double b) {m_b = b;};

	virtual double Eval(double x) const {return m_a*x + m_b;};

	virtual void Print() const;
	
private:
	double m_a, m_b;

};


/*
	DICHIARAZIONE FUNZIONE SOMMA
*/

class FunzioneSomma : public FunzioneBase {

public:
	//costruttore
	FunzioneSomma(FunzioneBase * f1, FunzioneBase * f2) {m_f1 = f1; m_f2 = f2;};
	virtual double Eval(double x) const {return m_f1->Eval(x) + m_f2->Eval(x);};

private:
	FunzioneBase * m_f1;
	FunzioneBase * m_f2;

};

/* 
	DICHIARAZIONE FUNZIONE PRODOTTO
*/

class FunzioneProdotto : public FunzioneBase {

public:
	//costruttore
	FunzioneProdotto(FunzioneBase * f1, FunzioneBase * f2) {m_f1 = f1; m_f2 = f2;};
	virtual	double Eval(double x) const {return m_f1->Eval(x)*m_f2->Eval(x);};

private:
	FunzioneBase * m_f1;
	FunzioneBase * m_f2;
};

/*
	DICHIARAZIONE FUNZIONE DIFFERENZA
*/

class FunzioneDifferenza : public FunzioneBase {

public:
	//costruttore
	FunzioneDifferenza(FunzioneBase * f1, FunzioneBase * f2) {m_f1 = f1; m_f2 = f2;};
	virtual	double Eval(double x) const {return m_f1->Eval(x)-m_f2->Eval(x);};

private:
	FunzioneBase * m_f1;
	FunzioneBase * m_f2;
};


/*
	DICHIARAZIONE GAUSSIANA - è una classe a parte, non è figlia di nessuna classe

*/
class Gaussiana {

public :

	//costruttore
	Gaussiana(double mean, double sigma) {
		m_mean = mean; 
		m_sigma = sigma;
	};

	double Eval(double x) const { 
		double c= 1/(m_sigma*sqrt(2*M_PI));
		double e = exp(-pow((x-m_mean), 2)/( 2*pow(m_sigma, 2) ));
		return e*c;
		}

private :
	double m_mean;
	double m_sigma;
};

#endif
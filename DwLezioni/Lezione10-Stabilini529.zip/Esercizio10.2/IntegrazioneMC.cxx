#include "IntegrazioneMC.h"
#include "Funzioni.h"
#include "RandomGen.h"
#include "statistica.h"
#include <cmath>
#include <vector>

using namespace std;

IntegraleMC::IntegraleMC(unsigned int seed) : 
	m_gen(seed),
	m_errore(0.)
{};

IntegraleMC::~IntegraleMC() {;};

/*====================================================================
METODI MEDIA
====================================================================*/

//media a numero di punti fissato
double IntegraleMC::Media(const FunzioneBase* f, double xmin, double xmax, unsigned int punti) {

	double sum = 0;
	double x = 0;

	for (int i=0; i<punti; i++) {
		x = m_gen.Unif(xmin, xmax);//estraggo un numero fissato di punti secondo una distribuzione uniforme
		//valuto la funzione nel punto estratto
		double fi = f->Eval(x);
		sum = sum + fi; //tengo traccia delle somme parziali
	}

	//al termine del ciclo aggiorno il seed per partire con un seed diversi se dovessi calcolare nuovamente il valore dell'integrale
	m_gen.SetSeed(m_gen.GetSeed()+1);

	return (sum/punti)*(xmax-xmin);
};


//Metodo di integrazione a precisione fissata (la stimo mediante il teorema del limite centrale)
double IntegraleMC::MediaFixedPrec(const FunzioneBase* f, double xmin, double xmax, double prec) {

	double sum = 0;
	double x = 0;
	vector<double> fi;
	double N = 100;

	for (int i=0; i<N; i++) {
		x = m_gen.Unif(xmin, xmax);//estraggo un numero fissato di punti secondo una distribuzione uniforme
		//valuto la funzione nel punto estratto
		double fi = f->Eval(x);
		sum = sum + fi; //tengo traccia delle somme parziali
	}

	double sigma_f = CalcolaDevCampione(fi);
	//stimo l'errore assoluto sull'integrale
	
	double N_new = pow((sigma_f*(xmax-xmin)/prec), 2);

	return Media(f, xmin, xmax, N_new);
};


//metodo di integrazione (montecarlo) della media a precisione fissata
double MediaFixedPrecGeneral(const FunzioneBase* f, double xmin, double xmax, double prec) {
	unsigned int M = 100; //numero di volte per cui calcolo l'integrale per poi stimare la deviazione standard
	double points = 100; //numero di punti con cui calcolo l'integrale
	vector<double> v;
	IntegraleMC myintegral(1);

	for (int i=0; i<M; i++){
		v.push_back(myintegral.Media(f, xmin, xmax, 100));
	}

	double dev = CalcolaDev(v);
	double k = dev*sqrt(points);
	double N = k*k/(prec*prec);

	double I = myintegral.Media(f, xmin, xmax, N);
	return I;
};


//metodo di integrazione (montecarlo) della media a precisione fissata in cui ho già calcolato M volte l'integrale e passo gli M valori in un vettore
template <typename T> double MediaFixedPrecGeneral(const FunzioneBase* f, double xmin, double xmax, double prec, const vector<T> v, double points) {
	IntegraleMC myintegral(1);

	double dev = CalcolaDev(v);
	double k = dev*sqrt(points); //points è il numero di punti con cui è stato clacolato l'integrale i cui valori sono raccolti in v;
	double N = k*k/(prec*prec);

	double I = myintegral.Media(f, xmin, xmax, N);
	return I;
};


/*====================================================================
	METODI DI INTEGRAZIONE HIT-MISS
====================================================================*/


//metodi HitMiss
double IntegraleMC::HitMiss(const FunzioneBase *f, double xmin, double xmax, unsigned int punti) {

	double hit = 0;
	double M = 0;

	//trovo il massimo della funzione
	double fback = f->Eval(xmin);
	for(double i=xmin; i<xmax; i = i+0.001) {
		double fi = f->Eval(i);
		if (fi-fback > 0) {
		  M = f->Eval(xmax-xmin/2); 
			break;
		}

		fback = fi;
	}

	for (int i=0; i<punti; i++) {
		double x = 0;
		double y = 0;
		x = m_gen.Unif(xmin, xmax);
		double fi = f->Eval(x);
		y = m_gen.Unif(0, M);
		if (y < fi)
			hit++;
	}

	m_gen.SetSeed(m_gen.GetSeed()+1);

	return (xmax-xmin)*M*(hit/punti);
}

//metodo di integrazione con massimo noto
double IntegraleMC::HitMiss(const FunzioneBase *f, double xmin, double xmax, unsigned int punti, double M) {

	double hit = 0;
	double max = M;

	//inserire un controllo sul numero dei punti?

	for (int i=0; i<punti; i++) {
		double x = 0;
		double y = 0;
		x = m_gen.Unif(xmin, xmax);
		double fi = f->Eval(x);
		y = m_gen.Unif(0, M);
		if (y < fi)
			hit++;
	}

	m_gen.SetSeed(m_gen.GetSeed()+1);

	return (xmax-xmin)*max*(hit/punti);
};


//metodo Hit Miss a precisione fissata con massimo noto
double HitMissFixedPrec(const FunzioneBase *f, double xmin, double xmax, double prec, double M) {
	unsigned int G = 100; //numero di volte per cui calcolo l'integrale per poi stimare la deviazione standard
	vector<double> v;
	IntegraleMC myintegral(1);

	for (int i=0; i<G; i++){
		v.push_back(myintegral.HitMiss(f, xmin, xmax, 100, M));
	}

	double dev = CalcolaDev(v);
	double k = dev*sqrt(100);
	double N = k*k/(prec*prec);

	double I = myintegral.HitMiss(f, xmin, xmax, N, M);
	return I;
};


//metodo hit miss a precisione fissata con massimo noto e a partire da valori già calcolati dell'integrale
template <typename T> double HitMissPrec(const FunzioneBase* f, double xmin, double xmax, double prec, double M, const vector<T> v, double points) {
	IntegraleMC myintegral(1);

//points indica il numero di punti che sono stai usati epr calcolare l'integrale (per i valori raccolti nel vetor)
	double dev = CalcolaDev(v);
	double k = dev*sqrt(points);
	double N = k*k/(prec*prec);

	double I = myintegral.HitMiss(f, xmin, xmax, N, M);
	return I;
};

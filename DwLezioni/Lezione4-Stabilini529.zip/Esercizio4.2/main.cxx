#include <iostream>
#include <fstream>
#include <cstdlib>
#include <vector>
#include <algorithm>
//#include "TH1F.h"
//#include "TApplication.h"
//#include "TCanvas.h"

#include "funzioni.h"
#include <string>
#include "posizione.h"

int main( /*int argc , char** argv*/ ) {
	//dichiarazione delle variabili
	vector<posizione> vp; //vettore di posizioni
	fstream f ("data_points.dat");

	//TApplication app("app",0,0);

	posizione p;
	
	if(!f) {
		cerr << "errore apertura file" << endl;
		exit(1);
	} else {
		while(!f.eof()) {
			f>> p;
			vp.push_back(p);
		}
	}

	for(vector <posizione>::iterator it = vp.begin() ; it != vp.end(); it++)
		it->printPositions();

	BestPath<vector<posizione>::iterator>(vp.begin(), vp.end());
	//il tipo di dato con cui funziona questo template sono gli iteratori di un vettore di tipo posizione

	for(vector <posizione>::iterator it = vp.begin() ; it != vp.end(); it++)
		it->printPositions();

	//TApplication app("app",0,0);

 //app.Run();


 return 0;
	  
}
#include "Vettore.h"
#include "funzioni_vec.h"

void PrintOnFile ( const char* Filename, const Vettore& V) {
  ofstream outfile(Filename);
  if(!outfile) {
    cerr << "errore apertura file risultati.dat" << endl;
    exit(0);
  }
  
	unsigned int size = V.GetN();
  for (int i=0; i<size; i++)
    outfile << V.GetComponent(i) << endl;
}

Vettore ReadDataFromFile (const char* filename, int size ) {
 	Vettore V(size);
  cout <<"inizio apertura file"<< endl;
  ifstream infile(filename);
  if (!infile) {
		cerr << "errore apertura file data.dat" << endl;
    exit(2);
  }

  for (int i = 0; i < size; i++) {
		double x = 0;
    if (infile.eof()) {
      cout << "fine dati da leggere" << endl;
       break;
    } else {
		infile >> x;
		V.SetComponent(i, x);
		}
  }
	
  return V;
}

void Vettore_selection_sort(Vettore& V) {
	unsigned int N = V.GetN();
  for ( int i=0; i < N; i++)
		  for ( int j=0; j < N; j++)
			  if(V.GetComponent(i)> V.GetComponent(j))
				 V.Scambia(i, j);	
}

void PrintOnScreen(const Vettore& V) {
	unsigned int N = V.GetN();
  for (int i=0; i<N; i++)
    cout << V.GetComponent(i) << endl;
}
#include <iostream>
#include <cmath>
#include <iomanip>
#define _USE_MATH_DEFINES


#include "Funzioni.h"
#include "Integral.h"

#include "TH1F.h"
#include "TApplication.h"
#include "TCanvas.h"
#include "TGraph.h"

using namespace std;

int main(int argc, const char ** argv){

  if (argc != 2) {
    cout << "Usage: ./main prec" << endl;
    return -1;
  }

  double a = 0.;
  double b = M_PI;

  double prec = atof(argv[1]);

  FunzioneBase* sinx = new Coseno(1, 1, - M_PI/2, 0);
	Integratore* myTrapezi = new Trapezi(a,b,sinx);

	cout << setprecision(12) << myTrapezi->IntegraPrec(prec) <<endl;
	
	delete[] sinx;
	delete[] myTrapezi;

  return 0;
}

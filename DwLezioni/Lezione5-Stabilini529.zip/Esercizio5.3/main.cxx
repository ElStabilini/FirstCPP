#include "Particella.h"
#include "Posizione.h"
#include "CampoVettoriale.h"
#include "PuntoMateriale.h"
#include <cmath>
#include <iostream>
#include "TH1F.h"
#include "TApplication.h"
#include "TCanvas.h"
#include "TGraph.h"

using namespace std;

int main(int argc , char** argv) {

	TApplication app("app",0,0);

	if ( argc != 4 ) {
    cerr << "Uso del programma : " << argv[0] << " <x> <y> <z>" << endl;
    return -1 ;
  }

	double x = atoi(argv[1]);
	double y = atoi(argv[2]);
	double z = atoi(argv[3]);
	
	const double mp = 1.67262E-27;
	const double d = 1E-10;
	
	Elettrone *e = new Elettrone();
	Posizione P(x*1E-5, y*1E-5, z*1E-5);


	Particella part(*e); //faccio sì che il mio elettrone venga visto dal codice come una particella creando una particella con le caratteristiche dell'elettrone usando il copy constructor

	PuntoMateriale electron(part, d/2, 0, 0);
	//NB: in teoria non serve far diventare *e una particella
	PuntoMateriale proton(mp, - e->getCarica(), -d/2, 0, 0);

	CampoVettoriale E = electron.CampoElettrico(P) + proton.CampoElettrico(P);
	
	cout << "campo elettrico risultante in P: " << endl;
	cout << "Ex = " << E.getFx() << endl;
	cout << "Ey = " << E.getFy() << endl;
	cout << "Ez = " << E.getFz() << endl;

	
	int k=0;
	TGraph *g = new TGraph();
	for (int i=100; i<=1000; i++) {
		double r =i*d; //dichiaro r così faccio scorrere le distanze su tutti i multipli di d nell'intervallo indicato dal ciclo for
		Posizione R(0,0,r); //dichiaro la posizione R inc ui calcolare il campo
		CampoVettoriale E_R = electron.CampoElettrico(R) + proton.CampoElettrico(R); //valuto il campo in R come somma dei campi elettrici in R
		double mod = E_R.Modulo(); //definisco il modulo del campo elettrico
		g->SetPoint(k,r,mod); //definisco le coordinate x=r y=mod sul pinao per il punto i-esimo
		k++;
	}

 	TCanvas * Plot = new TCanvas("Plot", "Andamento Campo Elettrico", 500, 500); //creo un puntatore a TCanvas che chiamo plot, fornisco come argomenti il nome del "file", il titolo del grafico, le dimensioni del canvas
	 Plot->cd(); //?
	 g->Draw("ACP*"); //disegno gli assi sul bordo del grafico e collego i punti con una linea
	 g->SetTitle("Campo elettrico sull'asse del dipolo");
	 g->GetXaxis()->SetTitle("distanza [m]");
	 g->GetYaxis()->SetTitle("Campo Elettrico [C]");

  app.Run();
	return 0;
}
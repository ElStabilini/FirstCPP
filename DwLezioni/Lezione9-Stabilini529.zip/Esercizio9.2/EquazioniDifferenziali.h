#ifndef __EQ_DIFF__
#define __EQ_DIFF__

#include "VectorOperations.h"
#include <cmath>

using namespace std;


// Classe astratta, restituisce la derivata nel punto x al tempo t
class FunzioneVettorialeBase {

public:
  virtual vector<double> Eval(double t, const vector<double> & x) const = 0;
};

// Caso fisico concreto

class OscillatoreArmonico : public FunzioneVettorialeBase {

public:

  OscillatoreArmonico(double omega0) { m_omega0 = omega0; };

  vector<double> Eval(double t, const vector<double> &x) const {
		//dato che qualunque vettore che entrà dovra essere pari (n/2 componenti per la posizione e n/2 per la velocità) inserisco un controllo su questo aspetto

		if(x.size()%2 != 0) {
			cout << "invalid position vector" << endl;
			exit(0);
		}
	
		//se entra un vettore con n dimensioni n/2 saranno per la posizione, da n/2 a n saranno velocità -> la derivata per le prime n/2 componenti saranno le seconde n/2; per le seconde n/2  saranno date da -wo^2*(corispondente prima n/2 componente)
		vector<double> derivative(x.size()); //costruisco il vettore derivata che deve essermi restituito
		double size = x.size();
		for (int i=0; i< size/2; i++)
			derivative[i] = x[i+size/2];

		for (int i=size/2; i<size; i++)
			derivative[i] = -	pow(m_omega0, 2)*x[i-size/2];
		
		return derivative;
  }

private:
  double m_omega0;
};

// Classe astratta per un integratore di equazioni differenziali

class EquazioneDifferenzialeBase {
public:
  virtual vector<double> Passo(double t, const vector<double> &x, double h, FunzioneVettorialeBase *f) const = 0;
};


// Integratore concreto, METODO DI EULERO

class Eulero : public EquazioneDifferenzialeBase {

public:

  vector<double> Passo(double t, const vector<double> &x, double h, FunzioneVettorialeBase *f) const {
		return x + (f->Eval(t, x))*h;
  }

};

class RungeKutta : public EquazioneDifferenzialeBase {

public :
	vector<double> Passo(double t, const vector<double> &x, double h, FunzioneVettorialeBase *f) const {
		double h2 = h/2;
		vector <double> k1 = f->Eval(t, x);
		vector <double> k2 = f->Eval(t + h2, x + (h2*k1));
		vector <double> k3 = f->Eval(t + h2, x + (k2*h2));
		vector <double> k4 = f->Eval(t + h, x + (k3*h));

		return x + (k1 + 2.*k2 + 2.*k3 + k4)*(h/6);
	}

};

#endif // __EQ_DIFF__

#include <iostream>

#include "TApplication.h"
#include "TCanvas.h" 
#include "TGraph.h"
#include "TAxis.h"

#include "EquazioniDifferenziali.h"
#include "Funzioni.h"
#include "VectorOperations.h"

using namespace std;

int main(int argc, char** argv){
  
  if(argc != 2)
  {
    cerr << "Uso: " << argv[0]  << " <passo_di_integrazione> " << endl;
    return -1;
  }

  TApplication myApp("myApp",0,0);

  RungeKutta myRK;

  Pendolo * p = new Pendolo (1.0);

  double h    = atof(argv[1]);
  vector<double> x {0.0, 1.0};
  double t = 0.0;

	TGraph *myGraph = new TGraph();
	
	int k=0;
	double t1=t;

	for (double A = 0.1; A < 3.1; A += 0.1 ) {
		x[0] = A;
		x[1] = 0;
		t=0 ;
		cout << "A = " << x[0] << endl;
		//A è la posizione iniziale del pendolo espressa come ampiezza quindi in rdianti, la velocità iniziale è nulla

		double v = 0;
		
		while (x[1]*v >= 0) {
				v = x[1];
				x = myRK.Passo(t,x,h,p);
				t1 = t;
				t = t+h;
		}

		//calcolo del periodo
		double T = t1 - v*h/(x[1] - v);
		T = 2*T;
		cout << "T =" << T<< endl;
		myGraph->SetPoint(k,A,T);
		k++;
	}	

	TCanvas *c1 = new TCanvas();
	c1->cd();
	string title = "Periodo - ampiezza (RungeKutta h = " + to_string(h) + ")";
	myGraph->SetTitle(title.c_str());
	myGraph->GetXaxis()->SetTitle("Ampiezza [rad]");
	myGraph->GetYaxis()->SetTitle("Periodo T [s]");
	myGraph->Draw("AL*");

	delete[] p;

  myApp.Run();

  return 0;
}

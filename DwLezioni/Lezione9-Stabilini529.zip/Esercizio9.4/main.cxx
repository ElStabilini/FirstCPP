#include <iostream>
#include <cmath>

#include "TApplication.h"
#include "TCanvas.h" 
#include "TGraph.h"
#include "TAxis.h"

#include "EquazioniDifferenziali.h"
#include "Funzioni.h"
#include "VectorOperations.h"

using namespace std;

int main(int argc, char** argv){
  
  if(argc != 5)
  {
    cerr << "Uso: " << argv[0]  << " <passo_di_integrazione> " << argv[1] << " <omega_0> " << argv[2] << " <alfa> " << argv[3] << " <omega_forzante> " << argv[4] << endl;
    return -1;
  }

  TApplication myApp("myApp",0,0);

  double tmax1 = 25.;
  double h    = atof(argv[1]);
	double omega_0 = atof(argv[2]);
	double alfa = atof(argv[3]);
	double omega_f = atof(argv[4]);
  vector<double> x {0.0, 0.0};
  double t = 0.0;
	double tmax2 = 10/alfa;

	cout << "alfa =" << alfa << endl;

	RungeKutta myRK;
  OscillatoreForzato * OscF = new OscillatoreForzato (omega_0, alfa, omega_f);


	TGraph *myGraph = new TGraph();
	int nstep = static_cast<int>(tmax1/h+0.5);
	
	int k=0;
	double t1=t;

	for (double i = 9;  i <= 11 ; i += 0.1 ) {
		t=0;
		x[1]=0;
		x[0]=0;
		OscF->SetOmegaF(i);
		cout << "omega = " << i << endl;
		double v = 0;

		//faccio evolvere il sistema
		for (int step = 0; step < nstep; step++){
    	x = myRK.Passo(t,x,h,OscF);
    	t = t+h;
  	}

		double a1=0;
		while (x[1]*v >= 0) {
			v = x[1];
			a1 = x[0];
			x = myRK.Passo(t,x,h,OscF);
			t = t+h;
		}
		double A1 = fabs( a1 - v*(x[0]-a1)/(x[1] - v));
		cout <<"A1 = " << A1 << endl;

		double a2=0;
		while (x[1]*v <= 0) {
			v = x[1];
			a2 = x[0];
			x = myRK.Passo(t,x,h,OscF);
			t = t+h;
		}
		double A2 = fabs( a2 - v*(x[0]-a2)/(x[1] - v));
		cout <<"A1 = " << A1 << endl;

		
		//calcolo delL'ampiezza
		double A = fabs(A2 + A1);
		cout << "A =" << A << endl;
		myGraph->SetPoint(k,i,A);
		k++;
}


	//GRAFICO DELLA SOLUZIONE
	TCanvas *c1 = new TCanvas();
	c1->cd();
	string title = "omega - ampiezza (RungeKutta h = " + to_string(h) + ")";
	myGraph->SetTitle(title.c_str());
	myGraph->GetXaxis()->SetTitle("omega [rad/s]");
	myGraph->GetYaxis()->SetTitle("A [u arb.]");
	myGraph->Draw("AL*");

	/*for (int step = 0; step < nstep; step++){
		myGraph->SetPoint(step,t,x[0]);
    x = myRK.Passo(t,x,h,OscF);
    t = t+h;
  }	
	cout << t << endl;

	TCanvas *c1 = new TCanvas();
	c1->cd();
	string title = "Oscillatore armonico (RungeKutta h = " + to_string(h) + ")";
	myGraph->SetTitle(title.c_str());
	myGraph->GetXaxis()->SetTitle("Tempo [s]");
	myGraph->GetYaxis()->SetTitle("Delta posizione x [m]");
	myGraph->Draw("AL");*/

	delete[] OscF;

  myApp.Run();

  return 0;
}

#include <iostream>
#include <cmath>
#include <string>
#include "Particella.h"

using namespace std;

int main (int argc , char** argv) {

	Particella *p = new Particella(1, 1.6E-19);
	Elettrone *e = new Elettrone();

	//prova metodi classe madre
	cout << "particella:" << endl;
	cout << "massa = " << p->GetMassa() << endl;
	cout << "carica = " << p->GetCarica() << endl;

	//prova metodi classe derivata
	cout << "elettrone:" << endl;
	cout << "massa = " << e->GetMassa() << endl;
	cout << "carica = " << e->GetCarica() << endl;

	//provo a usare il costruttore di copia
	Particella b(*p); //costruisco una particella a partire da una particella
	Particella d(*e); //costruisco una particella a partire da un elettrone
	Elettrone f(d); //ricostruisco un nuovo elettrone a partire dalla particella

	return 0;
}
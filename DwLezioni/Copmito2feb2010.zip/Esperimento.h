#ifndef _Esperimento_Prisma_h_
#define _Esperimento_Prisma_h

#include <cmath>
#include <vector>
#include "RandomGen.h"

using namespace std;

class Esperimento {

public :
	Esperimento(); //costruttore implementato nel .cxx
	~Esperimento() {;};

	void Esegui();
	void Analizza();
	vector<double> FonteErrore(int measures);

	double GetMainput() {return m_ma_input;};
	double GetMamisurato() {return m_ma_misurato;};
	double GetCainput() {return m_ca;};
	double GetTAinput() {return m_TA_input;};
	double GetTAmisurato() {return m_TA_misurato;};
	double GetMcinput() {return m_mc;};
	double GetTCinput() {return m_TC_input;};
	double GetTCmisurato() {return m_TC_misurato;};
	double GetTEinput() {return m_TE_input;};
	double GetTEmisurato() {return m_TE_misurato;};
	double GetMinput() {return m_m_input;}; 
	double GetMmisurato() {return m_m_misurato;};
	double GetCxinput() {return m_cx_input;};
	double GetCxmisurato() {return m_cx_misurato;};

	double GetSigmaMa() {return m_sigma_ma;};
	double GetSigmaTa() {return m_sigma_TA;};
	double GetSigmaTc() {return m_sigma_TC;};
	double GetSigmaTe() {return m_sigma_TE;};
	double GetSigmaM() {return m_sigma_m;};

	void SetSigmaMa(double Ma) {m_sigma_ma = Ma;};
	void SetSigmaTa(double Ta) {m_sigma_TA = Ta;};
	void SetSigmaTc(double Tc) {m_sigma_TC = Tc;};
	void SetSigmaTe(double Te) {m_sigma_TE = Te;};
	void SetSigmaM(double M) {m_sigma_m = M;};

private:

	RandomGen m_gen; //generatore di numeri casuali che viene dichiarato come datamembro privato perchè non deve cambiare fino alla fine "dell'esperimento" (il generatore deve aggiornare il seed di volta in volta in modo da restituire risultati diversi e non sempre lo stesso)

	double m_ma_input, m_ma_misurato;
	double m_sigma_ma;
	double m_ca;
	double m_TA_input, m_TA_misurato;
	double m_sigma_TA;
	double m_mc;
	double m_TC_input, m_TC_misurato;
	double m_sigma_TC;
	double m_TE_input, m_TE_misurato;
	double m_sigma_TE;
	double m_m_input, m_m_misurato;
	double m_sigma_m;
	double m_cx_input, m_cx_misurato;
	
};

#endif
#include <iostream>

#include "TApplication.h"
#include "TCanvas.h" 
#include "TGraph.h"
#include "TAxis.h"

#include "EquazioniDifferenziali.h"
#include "Funzioni.h"
//#include "VectorOperations.h"

using namespace std;

int main(int argc, char** argv){
  
  if(argc != 2)
  {
    cerr << "Uso: " << argv[0]  << " <passo_di_integrazione> " << endl;
    return -1;
  }

  TApplication myApp("myApp",0,0);

  Eulero myEuler;
	Coseno sinx {1, 1, - M_PI/2, 0};

  OscillatoreArmonico * osc = new OscillatoreArmonico (1.0);

  double tmax = 70.0;
  double h = atof(argv[1]);
  vector<double> x {0.0, 1.0};
  double t = 0.0;

  int nstep = static_cast<int>(tmax/h+0.5);
	TGraph *myGraph = new TGraph();
  
  for (int step = 0; step < nstep; step++){
		myGraph->SetPoint(step,t,x[0]);
    x = myEuler.Passo(t,x,h,osc);
    t = t+h;
  }	

	TCanvas *c = new TCanvas();
	c->cd();
	string title = "Oscillatore armonico (Eulero h = " + to_string(h) + ")";
	myGraph->SetTitle(title.c_str());
	myGraph->GetXaxis()->SetTitle("Tempo [s]");
	myGraph->GetYaxis()->SetTitle("Delta posizione x [m]");
	myGraph->Draw("AL");

	delete[] osc;

  myApp.Run();

  return 0;
}

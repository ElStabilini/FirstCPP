#include <iostream>
#include <cmath>

#include "TApplication.h"
#include "TCanvas.h" 
#include "TGraph.h"
#include "TAxis.h"

#include "EquazioniDifferenziali.h"
#include "Funzioni.h"
//#include "VectorOperations.h"

using namespace std;

int main(int argc, char** argv){
  
  if(argc != 2)
  {
    cerr << "Uso: " << argv[0]  << " <passo_di_integrazione> " << endl;
    return -1;
  }

  TApplication myApp("myApp",0,0);

  RungeKutta myRK;

  OscillatoreArmonico * osc = new OscillatoreArmonico (1.0);

  double tmax = 70.0;
  double h    = atof(argv[1]);
  vector<double> x {0.0, 1.0};
  double t = 0.0;


	//GRAFICO DELLA SOLUZIONE

  int nstep = static_cast<int>(tmax/h+0.5);
	TGraph *myGraph = new TGraph();
  
  for (int step = 0; step < nstep; step++){
		myGraph->SetPoint(step,t,x[0]);
    x = myRK.Passo(t,x,h,osc);
    t = t+h;
  }	

	TCanvas *c1 = new TCanvas();
	c1->cd();
	string title = "Oscillatore armonico (RungeKutta h = " + to_string(h) + ")";
	myGraph->SetTitle(title.c_str());
	myGraph->GetXaxis()->SetTitle("Tempo [s]");
	myGraph->GetYaxis()->SetTitle("Delta posizione x [m]");
	myGraph->Draw("AL");


	//ANDAMENTO DELL'ERRORE

	TGraph *errore = new TGraph();

	for (int i =0; i<10; i++) {
		double h = 0.1*pow(0.5, i);
		//riazzero le condizioni all'inizio di ogni ciclo
		vector<double> x1 {0, 1};
		double t = 0;
		int nstep = int(tmax/h + 0.5);

		for (int step=0; step < nstep; step++) {
			x1 = myRK.Passo(t, x1, h, osc);
			t = t+h;
		}

		double eps = fabs(x1[0] - sin(t));
		errore->SetPoint(i, log10(h), log10(eps));
	}

	TCanvas *c2 = new TCanvas();
	c2->cd();
	//string title = "Errore in funzione del passo";
	//errore->SetTitle(title.c_str());
	errore->GetXaxis()->SetTitle("Passo [h]");
	errore->GetYaxis()->SetTitle("Delta posizione x [m]");
	errore->GetYaxis()->SetLimits(0, 5 * 10E-6);
	errore->Draw("ALP");

	delete[] osc;

  myApp.Run();

  return 0;
}

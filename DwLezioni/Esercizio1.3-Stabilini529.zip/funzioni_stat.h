#include <iostream>
#include <fstream> 
#include <cstdlib>
#include <cmath>

using namespace std;

double CalcolaMedia( double * , int ) ;
double CalcolaVarianza( double * , int ) ;

double CalcolaMedia_improved( double * , int ) ;
double CalcolaVarianza_improved ( double * , int ) ;
double CalcolaMediana( double * , int ) ;
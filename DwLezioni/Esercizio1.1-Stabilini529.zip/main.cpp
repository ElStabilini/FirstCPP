#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>

using namespace std;

double CalcolaMedia( double * , int ) ;               
double CalcolaVarianza( double * , int );             
double CalcolaMediana ( double [] , int ) ;
double * ReadDataFromFile ( const char*  , int ) ;
void Print ( const char* , double * , int ) ;
double * CopyVec (double * , int );
void scambiaByValue(double , double ) ;               
void scambiaByRef(double &, double &) ;               
void scambiaByPointer(double *, double *) ;           
void selection_sort( double * , int );                



int main ( int argc , char** argv) {
  
  if ( argc < 3 ) {
    cout << "Uso del programma : " << argv[0] << " <n_data> <filename> " << endl;
    return -1 ;
  }
  
  int ndata = atoi(argv[1]);
  char * filename = argv[2];
  
  // uso una funzione per leggere gli elementi da un file

  double * data = ReadDataFromFile ( filename, ndata ) ;

  // [... aggiungo dei cout per visualizzare il contenuto del vettore ...]
  for (int i=0; i<ndata; i++)
    cout << data [i] << endl;
  // uso una funzione per calcolare la media e la varianza

  cout << "Media = " << CalcolaMedia( data , ndata ) << endl;

  cout << "Varianza = " << CalcolaVarianza( data , ndata ) << endl;
  
  //creo una copia del vettore
  double * copy = CopyVec(data, ndata);

    
  cout << "Mediana = " << CalcolaMediana(copy, ndata)<< endl;
  
  // Scrivo i dati e i dati riordinati su file
  Print( "fileout.txt", data, ndata ) ;
  
  delete [] data;
  delete [] copy;
  return 0;
}



//IMPLEMENTAZIONE FUNZIONI


// legge <size> elementi da <Filename> e restituisce un array
double * ReadDataFromFile ( const char* Filename , int size  ) {

  double * data = new double[size];
  
  ifstream infile(Filename);
  if (!infile) {
		cerr << "errore apertura file data.dat" << endl;
    exit(0);
  }

  for (int i = 0; i < size; i++) {
      infile >> data[i];
      if (infile.eof()) {
        cout << "fine dati da leggere" << endl;
        break;
      }
  }
  
  return data;
}

void Print ( const char* Filename, double * data, int size ) {
  ofstream outfile(Filename);
  if(!outfile) {
    cerr << "errore apertura file risultati.dat" << endl;
    exit(0);
  }
  
  for (int i=0; i<size; i++)
    outfile << data[i] << endl;

}

// calcola la media di <size> elementi dell'array <data>
double CalcolaMedia( double * data , int size ) {
  	  double sum = 0;
	  for (int i=0; i<size; i++)
		  sum = sum + data[i];
	return sum/size;
}

// calcola la varianza di <size> elementi dell'array <data>
double CalcolaVarianza( double * data , int size ) {
  double scarto = 0;
  for (int i=0; i<size; i++)
    scarto = scarto + pow(data[i] - CalcolaMedia(data, size), 2);
  return scarto/size;
}

// funzioni per scambiare di posto due elementi, utile per il riordinamento
void scambiaByValue(double a, double b) {
  double tmp = a;
	a = b;
	b = tmp;
}


void scambiaByRef(double &a, double &b) {
	double tmp = a;
	a = b;
	b = tmp;
}


//prende come argomento due variabili che puntano a una variabile di tipo double
void scambiaByPointer(double *a, double *b) {
	double c = *a; //creo una variabile di tipo double a cui viene assegnato il valore puntato da a
	*a = *b; //alla variabile puntata da a viene aasegnato il valore puntato dalla variabile b
	*b = c; //alla variabile puntata da b viene assegnato il valore di c

}

// algoritmo di riordinamento di un array ( selection_sort )  (riordino in ordine decrescente)
void selection_sort( double * vec , int size) {
  for (int i=0; i < size; i++)
		  for (int j=0; j < size; j++)
			  if(vec[i] > vec[j]) {
				  double tmp = vec[i];
			  	vec[i] = vec[j];
				  vec[j] = tmp;
			  }                  
}

double * CopyVec(double *vec,int size){
  double * copy = new double[size];
  for (int i=0; i< size; i++)
    copy[i] = vec[i];
  return copy;
}

double CalcolaMediana ( double vec[] , int size ) {
  double mediana = 0;
 
  //CopyVec(vec, size);
  double n=size/2;
  int x = (int)n;
  selection_sort(vec, size); //riordino il vettore copiato

    if (size%2 == 0) {  //se hai un numero pari di dati fai la media tra i due valori centrali
    mediana = (vec[x+1]+vec[x-1])/2;
      } else {       //se il numero di dati è dispari restituisce il valore centrale
    mediana = vec[x];
    }
  return mediana;
} 


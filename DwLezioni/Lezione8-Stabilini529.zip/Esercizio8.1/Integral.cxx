#ifndef __Integral_h__
#define __Integral_h__

#include <cmath>
#include <iomanip>

#include "iostream"
#include "Integral.h"
#include "Funzioni.h"

using namespace std;


double Midpoint::Integra(unsigned nstep) {
	m_h = (m_b - m_a)/double(nstep);
  m_sum = 0.;

  for (unsigned int i=0; i<nstep-1; i++){
    m_sum += m_f->Eval( m_a + (i+0.5)*m_h );
  }	

  m_integral = m_sign*m_sum*m_h;
  return m_integral;
};

double Simpson::Integra(unsigned nstep) {

	m_h = (m_b - m_a)/double(nstep);
  m_sum = 0.;

	double sum = 0;

	for (unsigned int i=1; i<nstep-1; i++) {
		if(i%2 == 0) {
			sum = sum + (4*m_f->Eval(m_a + i*m_h/*/2*/));
		} else { 
			sum = sum + (2*m_f->Eval(m_a + i*m_h/*/2*/));
		}
	}

	m_sum = sum;
	double f0 = m_f->Eval(m_a);
	double fn = m_f->Eval(m_b);
	m_integral = m_sign*(m_h/3)*(f0 + m_sum + fn);
	
};

#endif



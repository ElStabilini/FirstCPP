**Esercitazione 5 e 6**
Svolgeremo gli esercizi dell'esercitazione 5 suddividendoli su due esercitazioni.
Ricordo che solo l'esercizio 5.3 è da consegnare

Per l'esercizio 5.3 avrete bisogno di ROOT. Per scaricarlo nella vostra _main directory_ eseguite gli usuali comandi:
  * wget https://root.cern/download/root_v6.22.02.Linux-ubuntu18-x86_64-gcc7.5.tar.gz
  * tar -zxvf root_v6.22.02.Linux-ubuntu18-x86_64-gcc7.5.tar.gz
  * source setup.sh

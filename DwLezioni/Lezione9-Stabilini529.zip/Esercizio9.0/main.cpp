#include "VectorOperations.h"
#include <vector>
#include <iostream>
#include <cstdlib>

using namespace std;

int main() {

  vector<double> v1 { 3.,4.,6.} ;
  vector<double> v2 { 4.,5.,6.} ;

  double p = 2;

	cout << "v1*v2 = " << v1*v2 << endl;
	cout << "v1 + v2 = " << v1+v2 << endl;
	cout << "v1-v2 = " << v1-v2 << endl;
	cout << "p*v1 = " << p*v1 << endl;
	cout << "v1*p = " << v1*p << endl;

	return 0;
}
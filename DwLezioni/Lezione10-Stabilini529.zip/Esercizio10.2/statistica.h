#include <iostream>
#include <fstream> 

#include <vector>

using namespace std;

//FUNZIONI STAMPA VETTORI
template <typename T> void Print( const vector<T> & v ) {
  for (unsigned int i=0; i<v.size(); i++) cout << v[i] << endl;
};

template <typename T> void Print( const vector<T> & v  , char* filename ) {
	ofstream outfile(filename);
	if(!outfile) {
    cerr << "errore apertura file risultati.dat" << endl;
    exit(0);
  }
 
	for (int i=0; i<v.size(); i++)
		outfile << v[i] << endl;

	outfile.close();
	return;

};


//FUNZIONI STATISTICHE
template <typename T> double CalcolaMedia( const vector<T> & v) {
double sum = 0;
	for (int i=0; i<v.size(); i++)
		sum = sum + v[i];
	return sum/v.size();
};


template <typename T> double CalcolaMediana( vector<T> v ) {
	
	sort( v.begin(), v.end() ) ;  
  double mediana = 0;
	double x = v.size()/2;
	if (v.size()%2 == 0) {
		mediana = (v[v.size()/2]+v[v.size()/2 -1])/2;
	} else {
		int n = (int)x;
		mediana = v[x];
	}
  return mediana;
	
};

//Calcola VARIANZA
template <typename T> double CalcolaVarianza( const vector<T> & v) {
	double scarto = 0;
	double media = CalcolaMedia(v);
	for (int i=0; i<v.size(); i++)
  	scarto = scarto + pow(v[i] - media, 2);
	return scarto/v.size();
};

template <typename T> double CalcolaDev( const vector<T> & v) {
	return sqrt(CalcolaVarianza(v));
};

template <typename T> double CalcolaDevCampione( const vector<T> & v) {
	double scarto = 0;
	double media = CalcolaMedia(v);
	for (int i=0; i<v.size(); i++)
  	scarto = scarto + pow(v[i] - media, 2);
	return sqrt(scarto/(v.size()-1));
};

